/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Control.*;
import Modelo.*;
//se utilizan para copiar y pegar
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
//se utilizan para el color
import java.awt.Color;
import javax.swing.*;
import javax.swing.text.*;
import java.util.ArrayList;
/**
 *
 * @author w
 */
public class IDE extends javax.swing.JFrame {
    public static ArrayList<Simbolos> tblSimbolos;
    public static boolean CompilacionConExito=true;
    NumeroLinea numerolinea;
    Directorio dir;

    /**
     * Creates new form IDE
     */
    public IDE() {
        initComponents();
        inicializar();
    }
    
    @SuppressWarnings("static-access")
  private void inicializar() {
        setTitle("#noname");
        @SuppressWarnings("MismatchedReadAndWriteOfArray")
        String[] options = new String[]{"Guardar y continuar", "Abrir"};
        this.tblSimbolos= new ArrayList();
        dir = new Directorio();
        numerolinea = new NumeroLinea(jtpCode);//  se hace la numeracion
        jScrollPane1.setRowHeaderView(numerolinea);
        colors();
    }

  
//Para poner color a las plabras reservadas,variables,etc  
    private int findLastNonWordChar(String text, int index) {
        while (--index >= 0) {
            // \\W = [A-Za-Z0-9]
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
        }
        return index;
    }

    private int findFirstNonWordChar(String text, int index) {
        while (index < text.length()) {
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
            index++;
        }
        return index;
    }
//Para poner color a las plabras reservadas,variables,etc
    private void colors() {

        final StyleContext cont = StyleContext.getDefaultStyleContext();

        //atributos de Colores
        final AttributeSet attRojo  = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(192, 57, 43));
        final AttributeSet attVerde = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(35, 155, 86));
        final AttributeSet attMorado= cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(144, 56, 249));
        final AttributeSet attNegro = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(  0,   0,  0));
        final AttributeSet attAzul  = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(  0,  0,  225));
        final AttributeSet attm     = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(144,  0, 144));

        //Estilo
        DefaultStyledDocument doc = new DefaultStyledDocument() {
            @Override
            public void insertString(int offset, String str, AttributeSet a) throws BadLocationException {
                super.insertString(offset, str, a);

                String text = getText(0, getLength());
                int before = findLastNonWordChar(text,offset);
                if (before < 0) {
                    before = 0;
                }
                int after = findFirstNonWordChar(text,offset + str.length());
                int wordL = before;
                int wordR = before;

                while (wordR <= after) {
                    if (wordR == after || String.valueOf(text.charAt(wordR)).matches("\\W")) {
                        if (text.substring(wordL, wordR).toUpperCase().matches("(\\W)*(AND|ASM|ARRAY|BEGIN|"
                                + "CASE|CONST| CONSTRUCTOR|DESTRUCTOR|DIV|DO|DOWNTO|ESLES|END|EXPORTS|FILE|"
                                + "FOR|FUCTION|GOTO|IF|IMPLEMENTATION|IN|INHERITRD|INLINE|INTERFACE|ID|LABEL|"
                                + "LIBRARY|MOD|NIL|NOT|OBJECT|OF|OR|PACKED|PROCEDURE|PROGRAM|RECORD|REPEAT|"
                                + "SET|SHL|SHR|STRING|THEN|TO|TYPE|UNIT|UNTIL|USES|VAR|WHILE|WITH|XOR|"
                                + "PARENTESIS_APER|PARENTESIS_CIERRE)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attMorado, false);//palabras Resrvadas
                        } else if (text.substring(wordL, wordR).matches("(\\W)*(INTEGER|REAL|BOOLEAN|CHAR||STRING)")){
                            setCharacterAttributes(wordL, wordR - wordL, attAzul, false);
                        } else if (text.substring(wordL, wordR).toUpperCase().matches("(\\W)*(INTEGER|REAL|BOOLEAN|CHAR||STRING)")){
                            setCharacterAttributes(wordL, wordR - wordL, attVerde, false);//tipos de datos
                        } else if (text.substring(wordL, wordR).toUpperCase().matches("(\\W)*(WRITE|WRITELN|READ|READLN)")){
                            setCharacterAttributes(wordL, wordR - wordL, attRojo, false);//tipos de write y read
                        }else {
                            setCharacterAttributes(wordL, wordR - wordL, attNegro, false);
                        }
                        wordL = wordR;
                    }
                    wordR++;
                }
            }

            public void romeve(int offs, int len) throws BadLocationException {
                super.remove(offs, len);
                String text = getText(0, getLength());
                int before = findLastNonWordChar(text, offs);
                if (before < 0) {
                    before = 0;
                }
            }
        };
        JTextPane txt = new JTextPane(doc);
        String temp = jtpCode.getText();
        jtpCode.setStyledDocument(txt.getStyledDocument());
        jtpCode.setText(temp);
    }

//Limpia el area de codiog y consola
    public void clearAllComp() {
        jtaCompile.setText("");
        jtaList.setText("");
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jtpCode = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtaCompile = new javax.swing.JTextArea();
        btnGuardar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        btnAbrir = new javax.swing.JButton();
        btnReservadas = new javax.swing.JButton();
        btnIdentificadores = new javax.swing.JButton();
        btnTokens = new javax.swing.JButton();
        btnLexico = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnSintactico = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jtaList = new javax.swing.JTextArea();
        btnCopiar = new javax.swing.JButton();
        btnPegar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtpCode.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jtpCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtpCodeKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jtpCode);

        jtaCompile.setColumns(20);
        jtaCompile.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jtaCompile.setForeground(new java.awt.Color(0, 51, 255));
        jtaCompile.setRows(5);
        jScrollPane2.setViewportView(jtaCompile);

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Guardar.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Guardar.png"))); // NOI18N
        btnGuardar.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Guardar.png"))); // NOI18N
        btnGuardar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Guardar.png"))); // NOI18N
        btnGuardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Nuevo.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnNuevo.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Nuevo.png"))); // NOI18N
        btnNuevo.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Nuevo.png"))); // NOI18N
        btnNuevo.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Nuevo.png"))); // NOI18N
        btnNuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Abrir.png"))); // NOI18N
        btnAbrir.setText("Abrir");
        btnAbrir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAbrir.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Abrir.png"))); // NOI18N
        btnAbrir.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Abrir.png"))); // NOI18N
        btnAbrir.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Abrir.png"))); // NOI18N
        btnAbrir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });

        btnReservadas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Reservadas.png"))); // NOI18N
        btnReservadas.setText("Reservadas");
        btnReservadas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnReservadas.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Reservadas.png"))); // NOI18N
        btnReservadas.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Reservadas.png"))); // NOI18N
        btnReservadas.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Reseravadas.png"))); // NOI18N
        btnReservadas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnReservadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservadasActionPerformed(evt);
            }
        });

        btnIdentificadores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Identificadores.png"))); // NOI18N
        btnIdentificadores.setText("Identificadores");
        btnIdentificadores.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIdentificadores.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Identificadores.png"))); // NOI18N
        btnIdentificadores.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Identificadores.png"))); // NOI18N
        btnIdentificadores.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Identificadores.png"))); // NOI18N
        btnIdentificadores.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Identificadores.png"))); // NOI18N
        btnIdentificadores.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnIdentificadores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIdentificadoresActionPerformed(evt);
            }
        });

        btnTokens.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Tokens.png"))); // NOI18N
        btnTokens.setText("Tokens");
        btnTokens.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTokens.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Tokens.png"))); // NOI18N
        btnTokens.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Tokens.png"))); // NOI18N
        btnTokens.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Tokens.png"))); // NOI18N
        btnTokens.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Tokens.png"))); // NOI18N
        btnTokens.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTokens.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTokensActionPerformed(evt);
            }
        });

        btnLexico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Lexico.png"))); // NOI18N
        btnLexico.setText("Lexico");
        btnLexico.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnLexico.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Lexico.png"))); // NOI18N
        btnLexico.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Lexico.png"))); // NOI18N
        btnLexico.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Lexico.png"))); // NOI18N
        btnLexico.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Lexico.png"))); // NOI18N
        btnLexico.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnLexico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLexicoActionPerformed(evt);
            }
        });

        jLabel1.setText("Consola");

        btnSintactico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Sintactico.png"))); // NOI18N
        btnSintactico.setText("Sintactico");
        btnSintactico.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnSintactico.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Sintactico.png"))); // NOI18N
        btnSintactico.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Sintactico.png"))); // NOI18N
        btnSintactico.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Sintactico.png"))); // NOI18N
        btnSintactico.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Sintactico.png"))); // NOI18N
        btnSintactico.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnSintactico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSintacticoActionPerformed(evt);
            }
        });

        jtaList.setColumns(20);
        jtaList.setRows(5);
        jScrollPane3.setViewportView(jtaList);

        btnCopiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/copy .png"))); // NOI18N
        btnCopiar.setText("Copiar Codigo");
        btnCopiar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCopiar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/copy .png"))); // NOI18N
        btnCopiar.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/copy .png"))); // NOI18N
        btnCopiar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/copy.png"))); // NOI18N
        btnCopiar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCopiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCopiarActionPerformed(evt);
            }
        });

        btnPegar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/paste.png"))); // NOI18N
        btnPegar.setText("Pegar Codigo");
        btnPegar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPegar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/paste.png"))); // NOI18N
        btnPegar.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/paste.png"))); // NOI18N
        btnPegar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/paste.png"))); // NOI18N
        btnPegar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnPegar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPegarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 766, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnAbrir, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCopiar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPegar, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnReservadas, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnIdentificadores, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnTokens, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnLexico, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSintactico)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCopiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAbrir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPegar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnReservadas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnIdentificadores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTokens, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLexico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSintactico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 476, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        jtaCompile.setText("");
        dir.Nuevo(this);
        clearAllComp();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        dir.Guardar(this);
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        dir.Abrir(this);
        clearAllComp();
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnReservadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservadasActionPerformed
      jtaList.setText("");
        for(int i = 0; i < tblSimbolos.size(); i++){
         if (tblSimbolos.get(i).getTipo().equals(TOKEN.PR)){
            jtaList.setText(jtaList.getText()+ tblSimbolos.get(i).toString()+ "\n" );
         }
        }
    }//GEN-LAST:event_btnReservadasActionPerformed

    private void jtpCodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtpCodeKeyReleased
        //no permitir caracteres especiales en los nombres de archivos 
        int keyCode = evt.getKeyCode();
        //65:A-90:Z 48:0-57:1 97:a-122:z 40:0-16:1 
        if ((keyCode >= 65) && (keyCode <= 90) || (keyCode >= 48) && (keyCode <= 57)
                || (keyCode >= 97) && (keyCode <= 122) || (keyCode != 27) && !(keyCode >= 37
                && keyCode <= 40) && !(keyCode >= 16
                && keyCode <= 18) && !(keyCode != 254
                && keyCode != 20)) {
            if (!getTitle().contains("*")) {
                setTitle(getTitle() + "*");
            }

        }


    }//GEN-LAST:event_jtpCodeKeyReleased

    private void btnIdentificadoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIdentificadoresActionPerformed
       jtaList.setText("");
        for(int i = 0; i < tblSimbolos.size(); i++){
         if (tblSimbolos.get(i).getTipo().equals(TOKEN.ID)){
            jtaList.setText(jtaList.getText()+ tblSimbolos.get(i).toString()+ "\n" );
         }
        }
    }//GEN-LAST:event_btnIdentificadoresActionPerformed

    private void btnTokensActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTokensActionPerformed
        jtaList.setText("");
        for(int i = 0; i < tblSimbolos.size(); i++){
            jtaList.setText(jtaList.getText()+ tblSimbolos.get(i).toString()+ "\n" );
        }
    }//GEN-LAST:event_btnTokensActionPerformed

    private void btnLexicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLexicoActionPerformed
        clearAllComp();
        //lista_Reservadas.clear();lista_Identificadores.clear();
        tblSimbolos.clear();
        StringBuilder buffer = new StringBuilder();     
        TOKEN token;
        AnalizadorLexico a = new AnalizadorLexico(jtpCode.getText().toCharArray());
        do{
            token = a.automata();
            if (token != TOKEN.NEXT_TOKEN)
                    buffer.append(token.toString()+"\n");
        }while (token != TOKEN.EOF);
        jtaCompile.setForeground(Color.blue);
        jtaCompile.setText(buffer.toString());
        
    }//GEN-LAST:event_btnLexicoActionPerformed

    private void btnSintacticoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSintacticoActionPerformed
        clearAllComp();
        StringBuilder buffer = new StringBuilder();     
        ERRORES error;
        CompilacionConExito=true;
        AnalizadorSintactico s = new AnalizadorSintactico();
        do{
            error = s.AnalisisSintactico(jtpCode.getText().toCharArray());
            if (error != ERRORES.SIN_ERROR && error != ERRORES.EOF){
                    buffer.append(error.toString()+"\n"+s.Error);
                    //jtaCompile.setForeground(Color.red);//color rojo si hay errores
                    CompilacionConExito=false;
            } 
        }while (error != ERRORES.EOF && CompilacionConExito);
        if (CompilacionConExito){
            buffer.append(error.toString()+"\n"+s.Error); 
            jtaCompile.setForeground(Color.green);//color Verde compilacion exitosa
        }else jtaCompile.setForeground(Color.red);;//color rojo si hay errores
        jtaCompile.setText(buffer.toString());
    }//GEN-LAST:event_btnSintacticoActionPerformed

    private void btnCopiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCopiarActionPerformed
        StringSelection codigo= new StringSelection(jtpCode.getText());
        Clipboard cb =Toolkit.getDefaultToolkit().getSystemClipboard();
        cb.setContents(codigo,null);
    }//GEN-LAST:event_btnCopiarActionPerformed

    private void btnPegarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPegarActionPerformed
// Pegar del portapapeles texto 
        String codigo;
        Clipboard cb =Toolkit.getDefaultToolkit().getSystemClipboard();
        Transferable contenido = cb.getContents(null);
         if(contenido.isDataFlavorSupported(DataFlavor.stringFlavor)){
            try {
                codigo = (String) contenido.getTransferData(DataFlavor.stringFlavor);
                jtpCode.setText(codigo);
            } catch (UnsupportedFlavorException | IOException ex) {
                Logger.getLogger(IDE.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnPegarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new IDE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnCopiar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnIdentificadores;
    private javax.swing.JButton btnLexico;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnPegar;
    private javax.swing.JButton btnReservadas;
    private javax.swing.JButton btnSintactico;
    private javax.swing.JButton btnTokens;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jtaCompile;
    private javax.swing.JTextArea jtaList;
    public javax.swing.JTextPane jtpCode;
    // End of variables declaration//GEN-END:variables
}
