
package Control;

import Modelo.ERRORES;
import Modelo.Simbolos;
import Modelo.TOKEN;
import Vista.IDE.*;
import static Vista.IDE.tblSimbolos;
/**
 *
 * @author w
 */
public class AnalizadorSintactico{
  int TokenActual=0; //para la posicion del tocen actual
  Simbolos Token; //para obtener atributos de los Token lexema y no. linea
  TOKEN token; //para obtener tokens
  public String Error; //Almacena los menmajes de erro general
  char[] codigoS;  //para obtener el codigo 
  ERRORES HayError; //para o
  
  public AnalizadorSintactico(){
    this.TokenActual=0;//se apunta al primer token
    this.Error= "Compilacion exitosa";// mensaje de Error se inicializa a compilacion con exito
    this.token=TOKEN.NEXT_TOKEN;//token a siguiente token
    this.HayError=ERRORES.SIN_ERROR; //se apunta al primer token
  }
  
  public ERRORES AnalisisSintactico(char[] entradaS){
    this.codigoS=entradaS;//se le psa el codigo en forma de arreglo       
    AnalisisLexico();//se realiza el analisis Lexico para llnar la tblSimbolos
    Token = tblSimbolos.get(TokenActual);//pedir el primer token
    token = Token.getToken();//pedir el primer token
    HayError = ErroresLexicos(); // obtener los Errores Lexico
        do{
         if  (HayError==ERRORES.SIN_ERROR) {//si no hay errores
                HayError = Programa();//Analizar el programa
           }          
         if (HayError!=ERRORES.SIN_ERROR){//Si es difrente de sin errores
                 return HayError;}//retornar el error
           System.out.println(" AnaSint "+token.toString());           
        }while (token != TOKEN.EOF);//Si es el final de archivo o del codigo 
        return ERRORES.EOF;//retorna fin de arcihvo
  }

 //>>>>>>>>>>>> El Progrma  
  protected ERRORES Programa(){
   if (esTkActual(TOKEN.PROGRAM)){// si el token actual es PROGRAM entonces tine cabezera
     HayError = GramaticaCabecera(); //leer la Cabezera del programa
   }
   if (esTkActual(TOKEN.USES) && HayError == ERRORES.SIN_ERROR ){//si tiene uses Aplicar la gramatica si no hay erroes
    HayError = GramaticaUses();// CLASUSULA USES
   }
   if (HayError == ERRORES.SIN_ERROR ){//si no hay errores en USES
     do{ 
          HayError = GramaticaBloque(); //Leer el bloque de programa BLOQUE
         
      }while(!esTkActual(TOKEN.END)&& !esTkActual(TOKEN.EOF) && HayError == ERRORES.SIN_ERROR  );
    }
   if (HayError == ERRORES.SIN_ERROR){
    if(!esTkActual(TOKEN.EOF)){ // si no es el final de archivo despues del end.
         if (Parea(TOKEN.END)){ //verifica si es el end. del prog principal
           if (Parea(TOKEN.PUNTO)){//verifica si es el . del End del prog principal
                 return ERRORES.SIN_ERROR;//si Ok se  retorna SIN_ERROR
           }else return ERRORES.ERROR94;
         }else return ERRORES.ERROR113;
    }else{
      AntToken();//regresar uno atras
      if (Parea(TOKEN.PUNTO)) {//verifica si es el . del End del prog principal
        if (Parea(TOKEN.END)){//verifica End del prog principal
             AntToken();//regresar uno atras
        }else return ERRORES.ERROR113;;
       }else return ERRORES.ERROR10;
    }
   }
   return HayError; //se retorna lo que produjo el BLOQUE de programa 
  }
  
 //>>>>>>>>>>>> GrCabezera
  protected ERRORES GramaticaCabecera(){
   SgteToken(); //PROGRAM -->[id]-->(;)
    if (Parea(TOKEN.IDE)){//verificar ide la cabezera
      if (Parea(TOKEN.PUNTOYCOMA)){//verificar el ;
           return ERRORES.SIN_ERROR;//si Ok se  retorna SIN_ERROR
       }else return ERRORES.ERROR85;
     }else return ERRORES.ERROR2; 
  }
//>>>>>>>>>>>> GrUSES
  protected ERRORES GramaticaUses(){
   do{
   SgteToken();//USES -->[id]|[id1,id2,id3,..,ide]-->(;)
     if (Parea(TOKEN.IDE)){ //verificar si es un ide 
     }else return ERRORES.ERROR2; 
   }while(esTkActual(TOKEN.COMA));//si es una lista de ide 
  
   if (Parea(TOKEN.PUNTOYCOMA)) {//Al terminar verifcar el ; de fin de instruccion
         return ERRORES.SIN_ERROR;//si Ok se  retorna SIN_ERROR
   }else return ERRORES.ERROR85;
  }
//>>>>>>>>>>>> GrBloque 
 protected ERRORES GramaticaBloque(){ //GrBloq -->[GrDecls]-->|[GrBlqSent]-->
     HayError = GramaticaDeclaraciones();//hay errores en las declaraciones obtenerlos
     if (esTkActual(TOKEN.BEGIN) && HayError == ERRORES.SIN_ERROR ){ //sin Errores en Decls y inica un BloqdeProg BEGIN
        HayError= gramaticaBloqueSentencias();//hay errores el bloqque de sentencias (write,read, asignacion,for,while,ect
     }
    return HayError; //se retorna lo que produjo el BLOQUE 
 }
//>>>>>>>>>>>> GrDeclaraciones
  protected ERRORES GramaticaDeclaraciones(){ //GrBloq-->[GrLabel]|[GrConst]|[GrType|[GrVar]]-->
      switch (token){
         case LABEL: HayError= GramaticaLabel();break; //GrLabel
         case CONST: HayError= GramaticaConst();break; //GrConst
         case TYPE:  HayError= GramaticaType(); break; //GrTypes      
         case VAR:   HayError= GramaticaVar();  break; //GrVar  
     }
    return HayError; //se retorna lo que produjo las declaraciones
  }
//>>>>>>>>>>>> GrLabel
   protected ERRORES GramaticaLabel(){//GrLabel-->[Ide]|[Ide]->(,)->[Ide]->(,)..(,)->[Ide]->(;)
   do{
   SgteToken(); // CONST pedir el siguiente token
     if (Parea(TOKEN.IDE)){    //verificar si es un ide 
     }else return ERRORES.ERROR2; 
   }while(esTkActual(TOKEN.COMA));//si es una lista de ide,ide,ide,ide 
  
   if (Parea(TOKEN.PUNTOYCOMA)) {//verifcar el ; de fin de instruccion
         return ERRORES.SIN_ERROR;
   }else return ERRORES.ERROR85;
  }
//>>>>>>>>>>>> GrConst   
   protected ERRORES GramaticaConst(){//GrConst-->[Ide]->(=)->[Constantes]->->(;)
    SgteToken();//CONST pedir el siguiente token
     if (Parea(TOKEN.IDE)){ //verificar si es un ide 
       if (Parea(TOKEN.IGUAL)){ 
        do{   
          SgteToken();
        }while(token!=TOKEN.PUNTOYCOMA); //verifcar el ; de fin de instruccion
     }else return ERRORES.ERROR97;   
     }else return ERRORES.ERROR2; 
   if (Parea(TOKEN.PUNTOYCOMA)) {
         return ERRORES.SIN_ERROR;
   }else return ERRORES.ERROR85;
  }
//>>>>>>>>>>>> GrType
  protected ERRORES GramaticaType(){//GrTypet-->[Ide]->(=)->[Constantes]->->(;) 
   SgteToken();//TYPE pedir el siguiente token
     if (Parea(TOKEN.IDE)){ //verificar si es un ide 
       if (Parea(TOKEN.IGUAL)){ 
        do{   
          SgteToken();
        }while(token!=TOKEN.PUNTOYCOMA); //Lsita de ides
     }else return ERRORES.ERROR97;   
     }else return ERRORES.ERROR2; 
   if (Parea(TOKEN.PUNTOYCOMA)) {//verifcar el ; de fin de instruccion
         return ERRORES.SIN_ERROR;
   }else return ERRORES.ERROR85;
  }
//>>>>>>>>>>>> GrVar  
  protected ERRORES GramaticaVar(){//GrVar->[Ide]|[Ide,ide,ide,..ide]->(:)->[Tipos]->->(;) 
   do{  
      do{ SgteToken();//pedir el token siguiente
        if (Parea(TOKEN.IDE)){ //revisar si es un identificador
            }else return ERRORES.ERROR2; //no es un identificador emitir error
      }while(esTkActual(TOKEN.COMA));       
    
      if (Parea(TOKEN.DOS_PUNTOS)){
         HayError = gramaticaTipos(); //GrVar->[Ide]|[Ide,ide,ide,..ide]->(:)->[GrTipos]->(;) 
         if (HayError == ERRORES.SIN_ERROR)
            if (Parea(TOKEN.PUNTOYCOMA)){//verifcar el ; de fin de instruccion
               if (esTkActual(TOKEN.IDE)) AntToken();
            }else return ERRORES.ERROR85; 
          else return HayError;
       }else return ERRORES.ERROR86;       
   }while(!esTkTipo(TOKEN.PR)); 
  return ERRORES.SIN_ERROR;
  }
//>>>>>>>>>>>> GrTipos  
 protected ERRORES gramaticaTipos(){ //GrTipos->[integer]|[real]|[boolean]|[char]|[String]|->(:)->[Tipos]->->(;)      
    if (!TipoValido(token)){// Se verfifica si es un tipo valido [integer]|[real]|[boolean]|[char]|[String]
        AntToken();
        Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
        return ERRORES.ERROR21; 
    } else { SgteToken(); return ERRORES.SIN_ERROR;}
  }  
//>>>>>>>>>>>> GrBlqSentencias  
  protected ERRORES gramaticaBloqueSentencias(){
  ERRORES errorBS = ERRORES.SIN_ERROR; 
  SgteToken(); 
  do{  
        switch (token){
         case BEGIN:  //sentecia BEGIN
             errorBS = gramaticaBloqueSentencias(); 
             SgteToken(); 
         break;   
         case FOR:   //sentecia FOR
          errorBS = GramaticaFor(); 
         break;         
         case WHILE:  //sentecia WHILE
          errorBS = GramaticaWhile(); 
         break;             
         case REPEAT: //sentecia REPEAT
           errorBS = GramaticaRepeat(); 
         break; 
         case IF:  //sentecia IF
           errorBS = GramaticaIfThen(); 
         break;     
         case ELSE:  break;
         case IDE: //sentecia IDE
            SgteToken();
            if  (token==TOKEN.ASIGNACION)
             errorBS = gramaticaAsignacion();
         break;    
         case WRITE: case WRITELN: //sentecia WRITE O WRITELN
            errorBS= gramaticaWriteoWriteln();
         break;        
         case READ: case READLN: //sentecia READ O READLN
            errorBS= gramaticaReadoReadln();        
         break;   
         default:    
           if (!esTkActual(TOKEN.END) && !esTkActual(TOKEN.EOF)) SgteToken(); //Lee el token siguiente
             // si no es end de sentecia o final de archivo
         } 
      System.out.println(" "+token.toString());   
      if (errorBS != ERRORES.SIN_ERROR) return errorBS;
   }while(token!=TOKEN.END && token!=TOKEN.EOF );
   // mientras no sea end de sentecia o final de archivo produce sentencias
   return HayError; 
  }
  
//>>>>>>>>>>>> GrFor
protected ERRORES GramaticaFor(){  
SgteToken(); 
 if (Parea(TOKEN.IDE)){ 
  if (Parea(TOKEN.ASIGNACION)){ 
   if (Parea(TOKEN.NUM)){ 
    if (token==TOKEN.TO ||token==TOKEN.DOWNTO){
      SgteToken();
      if (Parea(TOKEN.NUM)){
       if (Parea(TOKEN.DO)){   
         return ERRORES.SIN_ERROR;
      }else return ERRORES.ERROR50;    
     }else return ERRORES.ERROR26;   
    }else return ERRORES.ERROR58;   
   }else return ERRORES.ERROR26;   
  }else return ERRORES.ERROR91;   
 }else return ERRORES.ERROR20; 
}
//>>>>>>>>>>>> GrWhile
protected ERRORES GramaticaWhile(){  
SgteToken(); 
do{
 if (esDato(token)){ //es un dato ->[ide|num|dec|cad]->
    SgteToken();
   if (esOpRel(token)){ //es OpRel->[>|<|<>|=|>=|<=]->
     SgteToken();
     if (esDato(token)){ //es un dato ide|num|dec|cad 
        SgteToken();
        if (esOpRel(token)){SgteToken();}//es OpRel->[And|Or]->
     }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
   }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
  }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
 }while(!esTkActual(TOKEN.DO)); //->(dato)->[>|<|<>|=|>=|<=]->(dato)-->
if (Parea(TOKEN.DO)){   
        return ERRORES.SIN_ERROR;
 }else return ERRORES.ERROR50; 
}
//>>>>>>>>>>>> GrIfThen
protected ERRORES GramaticaIfThen(){  
SgteToken(); 
do{
 if (esDato(token)){ //es un dato ->[ide|num|dec|cad]->
    SgteToken();
   if (esOpRel(token)){ //es OpRel->[>|<|<>|=|>=|<=]->
     SgteToken();
     if (esDato(token)){  //es un dato ide|num|dec|cad 
        SgteToken();
        if (esOpRel(token)){SgteToken();} // And o un Or
     }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
   }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
  }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
 }while(!esTkActual(TOKEN.THEN));
if (Parea(TOKEN.THEN)){   
     return ERRORES.SIN_ERROR;
 }else return ERRORES.ERROR57; 
}
//>>>>>>>>>>>> GrExpLogica para el until del repeat
protected ERRORES gramaticaExpLogica(){      
SgteToken();
do{
 if (esDato(token)){ //es un dato ide|num|dec|cad 
    SgteToken();
   if (esOpRel(token)){//es OpRel->[>|<|<>|=|>=|<=]->
     SgteToken();
     if (esDato(token)){ //es un dato ide|num|dec|cad 
        SgteToken();
        if (esOpRel(token)){SgteToken();}
     }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
   }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
  }else{ Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); return ERRORES.ERROR42; }
 }while(!esTkActual(TOKEN.PUNTOYCOMA));
return ERRORES.SIN_ERROR;
}

//>>>>>>>>>>>> GrRepeat
protected ERRORES GramaticaRepeat(){  //GrRepeat->¨[Sentencias]->(until)->[GrExpLogica]->
  SgteToken(); 
do{
   HayError = gramaticaSentencias(); //Sentencias writel,redln,ect.
 }while(!esTkActual(TOKEN.UNTIL));// ->(Until)->
   HayError = gramaticaExpLogica(); // ->[GrExpLogica]->
return HayError;
}
//>>>>>>>>>>>> GrSentencias
protected ERRORES gramaticaSentencias(){
ERRORES errorBS = ERRORES.SIN_ERROR; 
 switch (token){
         case BEGIN: 
             errorBS = gramaticaBloqueSentencias(); 
             SgteToken();  
         break;   
         case FOR:
          errorBS = GramaticaFor(); 
         break;         
         case WHILE:
          errorBS = GramaticaWhile(); 
         break;   
          case REPEAT:
           errorBS = GramaticaRepeat(); 
         break;      
         case IDE:
            SgteToken();
            if  (token==TOKEN.ASIGNACION)
             errorBS = gramaticaAsignacion();
         break;    
         case WRITE: case WRITELN:
            errorBS= gramaticaWriteoWriteln();
         break;        
         case READ: case READLN:
            errorBS= gramaticaReadoReadln();        
         break;   
         default:    
           if (!esTkActual(TOKEN.END) && !esTkActual(TOKEN.EOF)) SgteToken();
         } 
      System.out.println(" "+token.toString());   
      if (errorBS != ERRORES.SIN_ERROR) return errorBS;
return errorBS;
}

//>>>>>>>>>>>> GrExpSimple
protected ERRORES gramaticaExpSimple(){      
    if (esTkActual(TOKEN.COMA)){
        Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
        return ERRORES.ERROR42; 
    }
    else if (esDato(token) || esOpArit(token)||esOpRel(token)){
        SgteToken(); return ERRORES.SIN_ERROR;
    }
    else{
          AntToken();
          Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
          return ERRORES.ERROR64; 
     }
}
//>>>>>>>>>>>> GrWriteoWritln
protected ERRORES gramaticaWriteoWriteln(){
  SgteToken(); 
  if (token!=TOKEN.PUNTOYCOMA){
     if (Parea(TOKEN.PARENTESIS_APER)){ 
      do{ System.out.println(" GrW "+token.toString());
       do{  if (esTkActual(TOKEN.COMA)) SgteToken();//si es la coma de separacion pedir otro token
            HayError = gramaticaExpSimple();//revisar hay erroes en la expresion que se va a imprimir 
            if (HayError!=ERRORES.SIN_ERROR) return HayError;//si los hay retorna el error
       }while(esTkActual(TOKEN.COMA)); //si es la coma de separacion es una lista de expreciones      
      }while(token!= TOKEN.PARENTESIS_CIERRE && token != TOKEN.PUNTOYCOMA);
      if (Parea(TOKEN.PARENTESIS_CIERRE)){ // revisar si esta el parentesis que cierra
        if (Parea(TOKEN.PUNTOYCOMA)) {// revisar punto y coma
             return ERRORES.SIN_ERROR;
          }else return ERRORES.ERROR85; //falta punto y coma
       }else return ERRORES.ERROR89; //falta )  
    }else return ERRORES.ERROR85;
  }     
  return ERRORES.SIN_ERROR;
}
//>>>>>>>>>>>> GrReadoReadln
protected ERRORES gramaticaReadoReadln(){
  SgteToken(); 
  if (token!=TOKEN.PUNTOYCOMA){
     if (Parea(TOKEN.PARENTESIS_APER)){ 
      do{ System.out.println(" GrR "+token.toString());
       do{ if (esTkActual(TOKEN.COMA)) SgteToken();//si es la coma de separacion pedir otro token
        if (Parea(TOKEN.IDE)){ //revisar si es un identificador
            }else return ERRORES.ERROR20; //no es un identificador emitir error
      }while(esTkActual(TOKEN.COMA)); //si es la coma de separacion es una lista de expreciones      
      }while(token!= TOKEN.PARENTESIS_CIERRE && token != TOKEN.PUNTOYCOMA);
      if (Parea(TOKEN.PARENTESIS_CIERRE)){ // revisar si esta el parentesis que cierra
        if (Parea(TOKEN.PUNTOYCOMA)) {// revisar punto y coma
             return ERRORES.SIN_ERROR;
          }else return ERRORES.ERROR85; //falta punto y coma
       }else return ERRORES.ERROR89; //falta )  
    }else return ERRORES.ERROR85;
  }     
 return ERRORES.SIN_ERROR;
}
//>>>>>>>>>>>> GrAsignacion
protected ERRORES gramaticaAsignacion(){    
     SgteToken();     
      switch (token){
        case PUNTOYCOMA: //:=;
              Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
              return ERRORES.ERROR42;
        case PUNTO://:=.
              Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
              return ERRORES.ERROR42;             
        case CADENA://:='cad'
              HayError = gramaticaCadenas();
             break;    
        case SUMA: case RESTA:  //:=(+|-)[num]
              token = gramaticaNumSigno();
        break;    
        case NUM: case DEC:  case IDE://:=[num|Dec|ide]     
            token = gramaticaE();//:=GrE->ET|E+T|E-T|(E)|num|ide     
            if (token ==TOKEN.ERROR42){ 
              Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
              return ERRORES.ERROR42;
             }
            else if (token ==TOKEN.ERROR89) { 
              Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
              return ERRORES.ERROR89;
             }else if (Parea(TOKEN.PUNTOYCOMA)) {
                    return ERRORES.SIN_ERROR;  
                   }else return ERRORES.ERROR85; //falta puntoy coma 
        default:
            if (Parea(TOKEN.PUNTOYCOMA)) {
                    return ERRORES.SIN_ERROR;  
             }else return ERRORES.ERROR85; //falta puntoy coma 
      }              
    return ERRORES.SIN_ERROR;  
 }
//>>>>>>>>>>>> GrnumSigno
protected TOKEN gramaticaNumSigno(){ //:=(+|-)[num]
     if (esTkActual(TOKEN.SUMA) || esTkActual(TOKEN.RESTA)){
          SgteToken(); 
           if (esTeroFac(token)){
             SgteToken(); 
             if (esTkActual(TOKEN.PUNTOYCOMA)) return token;
             else AntToken();
           }
       }   
   return token;
 }
//>>>>>>>>>>>> GrnumCadenas
 protected ERRORES gramaticaCadenas(){//:=['ASCII']->(+)->['ASCII']->..->(+)->['ASCII']
      do{
          SgteToken(); 
         if (esTkActual(TOKEN.SUMA)){
           SgteToken(); 
           if (esTkActual(TOKEN.CADENA)){
             //concatenacion de  cadenas
            }
         } 
        } while(token!= TOKEN.PUNTOYCOMA); 
       if (Parea(TOKEN.PUNTOYCOMA)) {
                  return ERRORES.SIN_ERROR;  
       }else return ERRORES.ERROR85; //falta puntoy coma 
  
 } 
//>>>>>>>>>>>> GrE
protected TOKEN gramaticaE(){
 int pa=0; 
 System.out.print(" GrE "+token.toString());
     do{
       SgteToken(); 
       if (token!=TOKEN.PUNTOYCOMA){  
             if (esTkActual(TOKEN.PARENTESIS_CIERRE)){ 
                 System.out.print(" "+token.toString());     
                 SgteToken(); pa++;
                if (esTkActual(TOKEN.PUNTOYCOMA)) return token; 
             }          
             if (esOpArit(token) || esOpRel(token)){
               System.out.print(" "+token.toString());   
               SgteToken(); 
              if (esTkActual(TOKEN.PARENTESIS_APER)){ 
                 System.out.print(" "+token.toString());     
                 SgteToken(); 
                 pa++;
              }
                token=gramaticaNumSigno();
               if ( esTeroFac(token) || esTkActual(TOKEN.PUNTOYCOMA)){
                   System.out.print("d "+token.toString());
                }         
           }else return TOKEN.ERROR42;            
          //System.out.print(" "+token.toString());
       } 
      } while(token!= TOKEN.PUNTOYCOMA);  
     if (!esPar(pa)) return TOKEN.ERROR89; 
   return token;
 } 
  
  
//>>>>>>>>>>>> Siguiente token de la tblsimbolos
  protected void SgteToken(){
    //System.out.println(" SgteToken E "+token.toString()+" -> "+Token.toString());     
    TokenActual++;
    Token = tblSimbolos.get(TokenActual);
    token = Token.getToken();
    System.out.println(" SgteToken S "+token.toString()+" -> "+Token.toString());      
  };
//>>>>>>>>>>>> Anterior token de la tblsimbolos  
  protected void AntToken(){
    //System.out.println(" AntToken E "+token.toString()+" "+Token.toString());     
    TokenActual--;
    Token = tblSimbolos.get(TokenActual);
    token = Token.getToken();
    System.out.println(" AntToken S "+token.toString()+" "+Token.toString());      
  };
//>>>>>>>>>>>> Parea Token Actual con el que se le proporciona
  public boolean Parea(TOKEN Tk){  
   //System.out.println(" Parea E "+token.toString()+" "+Token.toString());    
    if(token.equals(Tk)){
       SgteToken();
  // System.out.println(" Parea S "+token.toString()+" "+Token.toString());         
       return true;
    }else{ 
        AntToken();
        Error="En "+Token.getLexema()+" en la linea "+Token.getLinea(); 
        return false;
    }
 }
 //>>>>>>>>>>>> Tipos Validos --->[INTEGER|REAL|CHAR|BOOLEAN|STRING]-->
 public boolean TipoValido(TOKEN TipoVar){  
     switch (TipoVar){ 
          case INTEGER: case CHAR: case REAL: case BOOLEAN: case STRING:               
                return true;
           default:
                return false;
      }
    }
//>>>>>>>>>>>> esDato   --->[CADENA|IDE|NUM|DEC]-->
 public boolean esDato(TOKEN TipoVar){  
     switch (TipoVar){ 
          case CADENA: case IDE: case NUM: case DEC:  
                return true;
           default:
                return false;
      }
    }
//>>>>>>>>>>>> esTerminooFactor   --->[IDE|NUM|DEC]-->
 public boolean esTeroFac(TOKEN TipoVar){  
     switch (TipoVar){ 
          case IDE: case NUM: case DEC:  
                return true;
           default:
                return false;
      }
  }
 //>>>>>>>>>>>> es Operador Aritmetico    --->[+|-|*|/]-->
 private boolean esOpArit(TOKEN Op){
  return (Op==TOKEN.SUMA || Op==TOKEN.RESTA || Op==TOKEN.MULTIPLICACION || Op==TOKEN.DIVISION);
 } 
 //>>>>>>>>>>>> es Operador Aritmetico    --->[+|-|*|/]-->
 private boolean esOpRel(TOKEN Op){
  return (Op==TOKEN.IGUAL || Op==TOKEN.MAYORQUE || Op==TOKEN.MENORQUE || Op==TOKEN.MAYORIGUALQUE || Op==TOKEN.MENORIGUALQUE || Op==TOKEN.DIFERENTE || Op==TOKEN.AND|| Op==TOKEN.OR);
 }
//>>>>>>>>>>>> es Token Actual   igual al propocionado
protected boolean esTkActual(TOKEN Tk){
    return token.equals(Tk);       
}
//>>>>>>>>>>>> es Token tipo CA,ID,CN,PR,CE,etc  igual al propocionado
protected boolean esTkTipo(TOKEN Tk){
    return Token.getTipo().equals(Tk);       
}  

 private boolean esPar(int P){
        return (P%2==0);
 } 

 //>>>>>>>>>>>> posibles Errores generados en el analizador lexico
 protected ERRORES ErroresLex(){
   switch (token){                    
             // ERRORES LEXICOS GENBERADOS POR EL ANALISS LEXICO
                case ERROR8:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR8; 
                case ERROR10:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR10; 
                case ERROR17:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR17; 
                case ERROR42:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR42; 
                case ERROR89:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR89;      
                case ERROR216:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR216;   
                default:                 
      
             }
   return ERRORES.SIN_ERROR;   
  }
//>>>>>>>>>>>> retorna los errores Lexcio como de cadens mal formadas numeros etc. 
protected ERRORES ErroresLexicos(){
 for(int i = 0; i < tblSimbolos.size(); i++){
    Token = tblSimbolos.get(TokenActual);//pedir el primer token
    token = Token.getToken();//pedir el primer token
    HayError = ErroresLex();//Errores del anlisis Lexico
    if  (HayError!=ERRORES.SIN_ERROR) 
        return HayError;//si los hay retorna el error  
 }
return ERRORES.SIN_ERROR;
} 
 
//>>>>>>>>>>>> Modoulo para cargar y actualizar la tblsimbolos cada vez que el usuario analise sintac  
protected void AnalisisLexico(){
AnalizadorLexico  Tokens = new AnalizadorLexico(codigoS);
tblSimbolos.clear();
   do{
        token = Tokens.automata();       
      }while (token != TOKEN.EOF);
   
  for(int i = 0; i < tblSimbolos.size(); i++){
    if (tblSimbolos.get(i).getToken().equals(TOKEN.COMENTARIO)){    
        tblSimbolos.remove(i);//remosver los comentarios
         }
      }
  } 
}//fin sitactico
