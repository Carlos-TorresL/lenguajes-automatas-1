package Modelo;

public class Simbolos {
    private TOKEN token;
    private String lexema;
    private int linea;
    private TOKEN tipo;
    
    public Simbolos() {
    }

    public Simbolos(TOKEN NToken, String lexema,int fila, TOKEN tipo) {
        this.token=NToken;
        this.lexema = lexema;
        this.linea = fila;
        this.tipo = tipo;
    }
 
public TOKEN getToken() {
        return token;
    }
    public void setToken(TOKEN token) {
        this.token = token;
    }
    public String getLexema() {
        return lexema;
    }
    public void setLexema(String lexema) {
        this.lexema = lexema;
    }
    public int getLinea() {
        return linea;
    }
    public void setLinea(int fila) {
        this.linea = fila;
    }
    public TOKEN getTipo() {
        return tipo;
    }
    public void setTipo(TOKEN tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "   linea " + linea +" lexema  " + lexema + "  tipo " + tipo + " ";
    }

}
