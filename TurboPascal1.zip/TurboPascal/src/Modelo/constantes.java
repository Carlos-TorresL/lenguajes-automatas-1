
package Modelo;

public class constantes{
    public final String Directivas="ABDEFGILMNORSVXabdefgilmnorsvx";
    public final String Letras="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    public final String Digitos="0123456789";
    public final String Delimitadores=";,. ";
     
    //Alfabetos
    public final String AlfabetoNumeros=Digitos+"+-.E"+Digitos;
    public final String AlfabetoIdeoReservada=Letras+Digitos+'_';      
    public String AlfabetoCadena; 
    public final String AlfabetoAsignacion=":=";
    
    public final char Apostrofo= '\'';
    public final char SaltoRenglon = '\n';
    public final char RetornoCarro = '\r';
    public final char Tabulador = '\t';
    public final char Espacio = ' ';
    public final char Ascii = '�';
    public final char DosPuntos = ':';
    public final char Igual = '=';
    public final char Mas = '+';
    public final char Menos = '-';
    public final char Exponencial = 'E';
    public final char Punto = '.';
    public final char GuionBajo='_';
    public final char MayorQue='>';
    public final char MenorQue='<';
    public final char Ll_A='{';
    public final char Ll_C='}';

    public constantes(){

      }

}