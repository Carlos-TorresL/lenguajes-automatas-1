package Modelo;

public enum TOKEN{
        AND,ASM,ARRAY,BEGIN,CASE,CONST,CONSTRUCTOR,DESTRUCTOR,DIV,DO,DOWNTO,ELSE,END,EXPORTS,FILE,FOR,FUNCTION,
        GOTO,IF,IMPLEMENTATION,IN,INHERITRD,INLINE,INTERFACE, IDE, LABEL,LIBRARY,MOD,NIL,NOT,OBJECT,OF,OR,PACKED,
        PROCEDURE,PROGRAM,RECORD,REPEAT,SET,SHL,SHR,STRING, THEN, TO, TYPE,UNIT,UNTIL,USES,VAR,WHILE,WITH,XOR,
        INTEGER,REAL,CHAR,CADENA,BOOLEAN,CAR, HEX, NUM,DEC,COMA,PUNTOYCOMA,DOS_PUNTOS,PUNTO_PUNTO,PUNTO,ASIGNACION,
        LLAVE_APER,LLAVE_CIERRE,CORCHETES_APER,CORCHETES_CIERRE,PARENTESIS_APER, PARENTESIS_CIERRE,SUMA,RESTA,
        MULTIPLICACION,DIVISION,IGUAL,DIFERENTE,MAYORQUE,MENORQUE,MAYORIGUALQUE,MENORIGUALQUE,WRITE,WRITELN,READ,
        READLN, AS,PR, OPA, OPR,CE,ID,CA,CN,CO,COMENTARIO,ERROR5,ERROR8,ERROR10,ERROR17,ERROR42,ERROR89,ERROR216, NEXT_TOKEN,EOF;
        @Override
        public String toString(){
            switch (this) {
                //palabras reservadas
                case AND:           return "AND";          
                case ASM:           return "ASM";                
                case ARRAY:         return "ARRAY";              
                case BEGIN:         return "BEGIN";        
                case CASE:          return "CASE";
                case CONST:         return "CONST";
                case CONSTRUCTOR:   return "CONSTRUCTOR"; 
                case DESTRUCTOR:    return "DESTRUCTOR"; 
                case DIV:           return "DIV";
                case DO:            return "DO"; 
                case DOWNTO:        return "DOWNTO";
                case ELSE:          return "ELSE"; 
                case END:           return "END"; 
                case EXPORTS:       return "EXPORTS";
                case FILE:          return "FILE";
                case FOR:           return "FOR";
                case FUNCTION:       return "FUNCTION"; 
                case GOTO:          return "GOTO";
                case IDE:            return "IDENTIFICADOR";
                case IF:            return "IF"; 
                case IMPLEMENTATION:return "IMPLEMENTATION"; 
                case IN:            return "IN"; 
                case INHERITRD:     return "INHERITRD"; 
                case INLINE:        return "INLINE"; 
                case INTERFACE:     return "INTERFACE";                
                case LABEL:         return "LABEL"; 
                case LIBRARY:       return "LIBRARY"; 
                case MOD:           return "MOD"; 
                case NIL:           return "NIL"; 
                case NOT:           return "NOT"; 
                case OBJECT:        return "OBJECT"; 
                case OF:            return "OF"; 
                case OR:            return "OR"; 
                case PACKED:        return "PACKED"; 
                case PROCEDURE:     return "PROCEDURE"; 
                case PROGRAM:       return "PROGRAM"; 
                case RECORD:        return "RECORD"; 
                case REPEAT:        return "REPEAT"; 
                case SET:           return "SET"; 
                case SHL:           return "SHL"; 
                case SHR:           return "SHR"; 
                case STRING:        return "STRING"; 
                case THEN:          return "THEN"; 
                case TO:            return "TO"; 
                case TYPE:          return "TYPE"; 
                case UNIT:          return "UNIT"; 
                case UNTIL:         return "UNTIL"; 
                case USES:          return "USES"; 
                case VAR:           return "VAR"; 
                case WHILE:         return "WHILE"; 
                case WITH:          return "WITH"; 
                case XOR:           return "XOR"; 
                //Identificadores estandar
                case WRITE:         return "WRITE";   
                case WRITELN:       return "WRITELN";   
                case READ:          return "READ";         
                case READLN:        return "READLN";       
                //tipos de datos
                case INTEGER:       return "INTEGER"; 
                case REAL:          return "REAL"; 
                case CHAR:          return "CHAR"; 
                case BOOLEAN:       return "BOOLEAN";   
                case CAR:           return "CARACTER ASCII";    
                case HEX:           return "CONSTANTE HEXADECIMAL";                    
                case NUM:           return "CONSTANTE ENTERA";    
                case DEC:           return "CONSTANTE DECIMAL";                    
                case CADENA:        return "CADENA";    
                //caracteres epeciales    
                case COMA:          return ",";
                case PUNTOYCOMA:    return ";";
                case DOS_PUNTOS:    return ":";                 
                case PUNTO_PUNTO:   return "..";                 
                case PUNTO:         return ".";                 
                case ASIGNACION:    return ":=";                     
           
               //Operadores Aritmeticos
                case MULTIPLICACION:return "*";
                case DIVISION:      return "/";
                case SUMA:          return "+";
                case RESTA:         return "-";   
                    
              //Operadores Relacionales
                case IGUAL:         return "=";
                case MAYORQUE:      return ">";
                case MENORQUE:      return "<";
                case DIFERENTE:     return "<>";
                case MAYORIGUALQUE: return ">=";
                case MENORIGUALQUE: return "<=";
                    
                case LLAVE_APER:        return "{";
                case LLAVE_CIERRE:      return "}"; 
                case COMENTARIO:        return "COMENTARIO";     
                case CORCHETES_APER:    return "[";
                case CORCHETES_CIERRE:  return "]";     
                case PARENTESIS_APER:   return "(";
                case PARENTESIS_CIERRE: return ")";        
                //tipos
                case PR:  return  "PR";
                case ID:  return  "Ide";
                case OPA: return  "OpArit";
                case OPR: return  "OpRel";
                case CE:  return  "Delim";
                case CN:  return  "Constante nuemrica";    
                case CO:  return  "{C}";
                case CA:  return  "Cadena";
                case AS:  return  "Asignacion";                 
                case ERROR5:
                    return "Error 5: Error de sintaxis"; 
                case ERROR8:
                    return "Error 8: Constante de cadena excede la linea"; 
                case ERROR10:
                    return "Error 10: No se esperaba fin de archivo";     
                case ERROR17:
                    return "Error 17: Directiva del compilador no valida";      
                case ERROR42:
                    return "Error 42: Error en la expresión";   
                case ERROR89:
                    return "Error 89: se esperaba \")\" ";      
                case ERROR216:
                    return "Error 216: comentarios anidados no permitidos";  
            default:
                return "";
            }
        }
    }