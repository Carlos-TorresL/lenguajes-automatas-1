/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Control;


import Modelo.ERRORES;
import Modelo.Simbolos;
import Modelo.TOKEN;
import Vista.IDE.*;
import static Vista.IDE.tblSimbolos;
/**
 *
 * @author w
 */
public class AnalizadorSintactico{
  int TokenActual=-1;
  boolean epsilon=false;
  Simbolos Token; 
  TOKEN token,TokenErr;
  public String Error;
  char[] codigoS;
  ERRORES HayError;
  
  public AnalizadorSintactico(){
    this.TokenActual=0;
    this.Error= "Compilacion exitosa";
   //this.codigoS=entrada;
    this.token=TOKEN.NEXT_TOKEN;
    this.HayError=ERRORES.SIN_ERROR; 
  }
  
  public ERRORES AnalisisSintactico(char[] entrada){
    this.codigoS=entrada;    
        //lista_Reservadas.clear();lista_Identificadores.clear();
        //tblSimbolos.clear();
       // StringBuilder buffer = new StringBuilder();     
    AnalisisLexico();
    Token = tblSimbolos.get(TokenActual);
    token = Token.getToken();
    HayError = ErroresLexicos();
               
        do{
           //HayError = ErroresLexicos();
         if  (HayError==ERRORES.SIN_ERROR) {
                 HayError = Programa();
           }          
         if (HayError!=ERRORES.SIN_ERROR){ 
                 return HayError;}
           System.out.println(" AnaSint "+token.toString());           
        }while (token != TOKEN.EOF);
        return ERRORES.EOF;  
  }

 
  
  protected ERRORES Programa(){
   if (esTkActual(TOKEN.PROGRAM)){
     HayError = GramaticaCabecera(); //CABESERA DE PROGRAMA
   }
   if (esTkActual(TOKEN.USES) && HayError == ERRORES.SIN_ERROR ){
               HayError = GramaticaUses();// CLASUSULA USES
   }
   if (HayError == ERRORES.SIN_ERROR ){
     do{ 
                 HayError = GramaticaBloque(); //BLOQUE
      }while(!esTkActual(TOKEN.END)&& !esTkActual(TOKEN.EOF) && HayError == ERRORES.SIN_ERROR  );
   }
   if (HayError == ERRORES.SIN_ERROR){
    if(!esTkActual(TOKEN.EOF)){ 
       if (Parea(TOKEN.END)) {   
         if (Parea(TOKEN.PUNTO)) {
           return ERRORES.SIN_ERROR;
        }else return ERRORES.ERROR94;
      }else return ERRORES.ERROR113;
    }else{
      AntToken();
      if (Parea(TOKEN.PUNTO)) {
        if (Parea(TOKEN.END)){ 
          AntToken();
        }else return ERRORES.ERROR113;;
       }else return ERRORES.ERROR10;
    }
   }
   return HayError; 
  }
  
  
  protected ERRORES GramaticaCabecera(){
   SgteToken();
    if (Parea(TOKEN.IDE)){ 
      if (Parea(TOKEN.PUNTOYCOMA)) {
           return ERRORES.SIN_ERROR;
       }else return ERRORES.ERROR85;
     }else return ERRORES.ERROR2; 
  }
  
  protected ERRORES GramaticaUses(){
   do{
   SgteToken();
     if (Parea(TOKEN.IDE)){ 
     }else return ERRORES.ERROR2; 
   }while(esTkActual(TOKEN.COMA));
  
   if (Parea(TOKEN.PUNTOYCOMA)) {
         return ERRORES.SIN_ERROR;
   }else return ERRORES.ERROR85;
  }
  
  protected ERRORES GramaticaBloque(){
    HayError = GramaticaDeclaraciones();
     if (esTkActual(TOKEN.BEGIN) && HayError == ERRORES.SIN_ERROR ){ 
        HayError= gramaticaBloqueSentencias();
     }
    return HayError; 
  }
  protected ERRORES GramaticaDeclaraciones(){
      switch (token){
         case LABEL:    break; 
         case CONST:    break; 
         case TYPE:  HayError= GramaticaType();   break;       
         case VAR:   HayError= GramaticaVar(); break;   
     }
    return HayError; 
  }
  
  protected ERRORES GramaticaType(){
   
   SgteToken();
     if (Parea(TOKEN.IDE)){ 
       if (Parea(TOKEN.IGUAL)){ 
        do{   
          SgteToken();
        }while(token!=TOKEN.PUNTOYCOMA); 
     }else return ERRORES.ERROR97;   
     }else return ERRORES.ERROR2; 
   if (Parea(TOKEN.PUNTOYCOMA)) {
         return ERRORES.SIN_ERROR;
   }else return ERRORES.ERROR85;
  }
  
  protected ERRORES gramaticaBloqueSentencias(){
  ERRORES errorBS = ERRORES.SIN_ERROR; 
  SgteToken(); 
  do{  
        switch (token){
         case IDE:
            SgteToken();
            if  (token==TOKEN.ASIGNACION)
             errorBS = gramaticaAsignacion();
         break;    
         case WRITE: case WRITELN:
            errorBS= gramaticaWriteoWriteln();
         break;        
         case READ: case READLN:
            errorBS= gramaticaReadoReadln();        
         break;   
         default:    
           if (!esTkActual(TOKEN.END) && !esTkActual(TOKEN.EOF)) SgteToken();
         } 
    System.out.println(" "+token.toString());   
   if (errorBS != ERRORES.SIN_ERROR) return errorBS;
   }while(token!=TOKEN.END && token!=TOKEN.EOF );    
   return HayError; 
  }
  
  protected ERRORES GramaticaVar(){
   do{  
      do{ SgteToken();//pedir el token siguiente
        if (Parea(TOKEN.IDE)){ //revisar si es un identificador
            }else return ERRORES.ERROR2; //no es un identificador emitir error
      }while(esTkActual(TOKEN.COMA));       
    
      if (Parea(TOKEN.DOS_PUNTOS)){
         HayError = gramaticaTipos();
         if (HayError == ERRORES.SIN_ERROR)
            if (Parea(TOKEN.PUNTOYCOMA)){
               if (esTkActual(TOKEN.IDE)) AntToken();
            }else return ERRORES.ERROR85; 
          else return HayError;
       }else return ERRORES.ERROR86;       
   }while(!esTkTipo(TOKEN.PR)); 
  return ERRORES.SIN_ERROR;
  }
  
 protected ERRORES gramaticaTipos(){      
    if (!TipoValido(token)){
        AntToken();
        Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
        return ERRORES.ERROR21; 
    } else { SgteToken(); return ERRORES.SIN_ERROR;}
  }  
  
  protected ERRORES gramaticaExpSimple(){      
    if (esTkActual(TOKEN.COMA)|| esOpArit(token)||esOpRel(token)){
        Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
        return ERRORES.ERROR42; 
    }
    else if (esDato(token)){
        SgteToken(); return ERRORES.SIN_ERROR;
    }
    else{
          AntToken();
          Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
          return ERRORES.ERROR64; 
     }
      
    }
 
  
protected ERRORES gramaticaWriteoWriteln(){
  SgteToken(); 
  if (token!=TOKEN.PUNTOYCOMA){
     if (Parea(TOKEN.PARENTESIS_APER)){ 
      do{ System.out.println(" GrW "+token.toString());
          HayError = ErroresLexicos(); //revisar si hay errores lexicos de cadenas,num,dec
          if  (HayError!=ERRORES.SIN_ERROR) return HayError;//si los hay retorna el error
       do{  if (esTkActual(TOKEN.COMA)) SgteToken();//si es la coma de separacion pedir otro token
            HayError = gramaticaExpSimple();//revisar hay erroes en la expresion que se va a imprimir 
            if (HayError!=ERRORES.SIN_ERROR) return HayError;//si los hay retorna el error
       }while(esTkActual(TOKEN.COMA)); //si es la coma de separacion es una lista de expreciones      
      }while(token!= TOKEN.PARENTESIS_CIERRE && token != TOKEN.PUNTOYCOMA);
      if (Parea(TOKEN.PARENTESIS_CIERRE)){ // revisar si esta el parentesis que cierra
        if (Parea(TOKEN.PUNTOYCOMA)) {// revisar punto y coma
             return ERRORES.SIN_ERROR;
          }else return ERRORES.ERROR85; //falta punto y coma
       }else return ERRORES.ERROR89; //falta )  
    }
  }     
  return ERRORES.SIN_ERROR;
}

protected ERRORES gramaticaReadoReadln(){
  SgteToken(); 
  if (token!=TOKEN.PUNTOYCOMA){
     if (Parea(TOKEN.PARENTESIS_APER)){ 
      do{ System.out.println(" GrR "+token.toString());
          HayError = ErroresLexicos(); //revisar si hay errores lexicos de cadenas,num,dec
          if  (HayError!=ERRORES.SIN_ERROR) return HayError;//si los hay retorna el error
       do{ if (esTkActual(TOKEN.COMA)) SgteToken();//si es la coma de separacion pedir otro token
        if (Parea(TOKEN.IDE)){ //revisar si es un identificador
            }else return ERRORES.ERROR20; //no es un identificador emitir error
      }while(esTkActual(TOKEN.COMA)); //si es la coma de separacion es una lista de expreciones      
      }while(token!= TOKEN.PARENTESIS_CIERRE && token != TOKEN.PUNTOYCOMA);
      if (Parea(TOKEN.PARENTESIS_CIERRE)){ // revisar si esta el parentesis que cierra
        if (Parea(TOKEN.PUNTOYCOMA)) {// revisar punto y coma
             return ERRORES.SIN_ERROR;
          }else return ERRORES.ERROR85; //falta punto y coma
       }else return ERRORES.ERROR89; //falta )  
    }
  }     
 return ERRORES.SIN_ERROR;
}

protected ERRORES gramaticaAsignacion(){    
     SgteToken(); 
      switch (token){
        case PUNTOYCOMA:
              Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
              return ERRORES.ERROR42;
        case PUNTO:
              Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
              return ERRORES.ERROR42;             
        case CADENA:
              HayError = gramaticaCadenas();
             break;    
        case SUMA: case RESTA:  
              token = gramaticaNumSigno();
        break;    
        case NUM: case DEC:  case ID:            
            token = gramaticaE();
            if (token==TOKEN.ERROR42){ 
              Error="Error "+Token.getLexema()+" en la linea "+Token.getLinea(); 
              return ERRORES.ERROR42;
             }else if (Parea(TOKEN.PUNTOYCOMA)) {
                    return ERRORES.SIN_ERROR;  
                   }else return ERRORES.ERROR85; //falta puntoy coma 
             
      }           
   
    return ERRORES.SIN_ERROR;  
 }
protected TOKEN gramaticaNumSigno(){
     if (token==TOKEN.SUMA || token==TOKEN.SUMA){
          SgteToken(); 
           if (token==TOKEN.IDE || Token.getTipo()==TOKEN.CN){
           SgteToken(); 
           if (token==TOKEN.PUNTOYCOMA)
                return token;
           }
       }   
   return token;
 }
 
  protected ERRORES gramaticaCadenas(){
      do{
          SgteToken(); 
         if (token==TOKEN.SUMA){
           SgteToken(); 
           if (token==TOKEN.CADENA){
             //concatenacion de  cadenas
            }
         } 
        } while(token!= TOKEN.PUNTOYCOMA); 
       if (Parea(TOKEN.PUNTOYCOMA)) {
                  return ERRORES.SIN_ERROR;  
       }else return ERRORES.ERROR85; //falta puntoy coma 
  
 } 

protected TOKEN gramaticaE(){
 int pa=0; 
     do{
       SgteToken(); 
       System.out.println(" GrE "+token.toString());
        if (token!=TOKEN.PUNTOYCOMA){  
          if (token==TOKEN.PARENTESIS_APER || token==TOKEN.PARENTESIS_CIERRE){ SgteToken(); pa++; }
             if (esOpArit(token) || esOpRel(token)){          
               SgteToken(); 
              if (token==TOKEN.PARENTESIS_APER || token==TOKEN.PARENTESIS_CIERRE){ SgteToken(); pa++;}
               if (token==TOKEN.ID || token==TOKEN.NUM || token==TOKEN.DEC || token==TOKEN.PUNTOYCOMA){
                 
                }
           }else return TOKEN.ERROR42;            
          System.out.println(" GrE S "+token.toString());
       } 
      } while(token!= TOKEN.PUNTOYCOMA);  
   // if (!esPar(pa)) return TOKEN.ERROR42; 
   return token;
 } 
  
  
protected ERRORES ErroresLexicos(){
   switch (token){                    
             // ERRORES LEXICOS GENBERADOS POR EL ANALISS LEXICO
                case ERROR8:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR8; 
                case ERROR10:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR10; 
                case ERROR17:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR17; 
                case ERROR42:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR42; 
                case ERROR89:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR89;      
                case ERROR216:
                     Error="En "+Token.getLexema()+" en la linea "+Token.getLinea();  
                     return ERRORES.ERROR216;   
                default:                 
      
             }
   return ERRORES.SIN_ERROR;   
  }
 
  protected void SgteToken(){
    System.out.println(" SgteToken E "+token.toString()+" "+Token.toString());     
    TokenActual++;
    Token = tblSimbolos.get(TokenActual);
    token = Token.getToken();
    System.out.println(" SgteToken S "+token.toString()+" "+Token.toString());      
  };
  
  protected void AntToken(){
    //System.out.println(" AntToken E "+token.toString()+" "+Token.toString());     
    TokenActual--;
    Token = tblSimbolos.get(TokenActual);
    token = Token.getToken();
    System.out.println(" AntToken S "+token.toString()+" "+Token.toString());      
  };
  
  public boolean Parea(TOKEN Tk){  
   //System.out.println(" Parea E "+token.toString()+" "+Token.toString());    
    if(token.equals(Tk)){
       SgteToken();
  // System.out.println(" Parea S "+token.toString()+" "+Token.toString());         
       return true;
    }else{ 
        AntToken();
        Error="En "+Token.getLexema()+" en la linea "+Token.getLinea(); 
        return false;
    }
 }
  
 public boolean TipoValido(TOKEN TipoVar){  
     switch (TipoVar){ 
          case INTEGER: case CHAR: case REAL: case BOOLEAN:        
                return true;
           default:
                return false;
      }
    }

 public boolean esDato(TOKEN TipoVar){  
     switch (TipoVar){ 
          case CADENA: case IDE: case NUM: case DEC:  
                return true;
           default:
                return false;
      }
    }

 private boolean esOpArit(TOKEN Op){
  return (Op==TOKEN.SUMA || Op==TOKEN.RESTA || Op==TOKEN.MULTIPLICACION || Op==TOKEN.DIVISION);
 } 
 
 private boolean esOpRel(TOKEN Op){
  return (Op==TOKEN.IGUAL || Op==TOKEN.MAYORQUE || Op==TOKEN.MENORQUE || Op==TOKEN.MAYORIGUALQUE || Op==TOKEN.MENORIGUALQUE || Op==TOKEN.DIFERENTE || Op==TOKEN.AND|| Op==TOKEN.OR);
 }
 
protected boolean esTkActual(TOKEN Tk){
    return token.equals(Tk);       
}

protected boolean esTkTipo(TOKEN Tk){
    return Token.getTipo().equals(Tk);       
}  
 
 private boolean esPar(int P){
        return (P%2==0);
 } 
 

protected void AnalisisLexico(){
AnalizadorLexico  Tokens = new AnalizadorLexico(codigoS);
tblSimbolos.clear();
   do{
        token = Tokens.automata();
      }while (token != TOKEN.EOF);
 }
}
