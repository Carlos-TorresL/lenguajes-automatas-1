

package Control;

import Modelo.*;

public class AnalizadorLexico {
   constantes c;
   Q Estado;
   boolean BuscarToken,EsSumaoResta;
   int estado;
   char[] entrada;
   int posicion;
   String lexema = "";
   int linea;
   char car;
    
//CONTRUCTOR
    public AnalizadorLexico(char[] entrada, boolean Compilar) {   
        this.c =new constantes();
        this.estado = 0;
        this.entrada = entrada;
        this.posicion = 0;
        this.linea=1;
        this.BuscarToken=Compilar;
        this.EsSumaoResta=false;
    }
      
     public TOKEN automata(){
      TOKEN QueEs;
      
        while ((this.posicion!=this.entrada.length) && BuscarToken){
         car = this.entrada[this.posicion]; 
        
        if (car==c.SaltoRenglon || car==c.RetornoCarro) { linea++;this.posicion++;}
        else if(car==c.Tabulador || car==c.Espacio){ this.posicion++;}
        else if(car==c.Apostrofo)
        {  
            return AFD_Cadena();
        }    
        else if (esLetra(car)||car==c.GuionBajo)
        {  
            return AFD_IDoRES();
         
        }    
        else if ("()[],;*/+-".contains(""+car)){    
           //lexema=""+car;
           this.posicion++;
            switch(car){
               case ';': return TOKEN.PUNTOYCOMA;
               case ',': return TOKEN.COMA;
               case '(':{ EsSumaoResta=true; return TOKEN.PARENTESIS_APER;}
               case ')': return TOKEN.PARENTESIS_CIERRE;    
               case '*': return TOKEN.MULTIPLICACION;
               case '/': return TOKEN.DIVISION;
               case '+':{  EsSumaoResta=false; return TOKEN.SUMA;}
               case '-': return TOKEN.RESTA;             
           }
        }else if(car==c.DosPuntos){
            EsSumaoResta=true; 
            return AFD_DosPuntos();
          }else if (esDigito(car)||car==c.Mas|| car==c.Menos){
              return AFD_EnteroReal();
          }else{          
          this.posicion++;
        }
        System.out.println(" "+lexema+" "+car);
     }   
       return  TOKEN.EOF;    
     }
     
     protected boolean esAlfabetoCadena(char simbolo){
        boolean PerteneceAlfabeto = true; //No pertenece
        if ((simbolo==c.Apostrofo) && (lexema.length()==0))
        { 
            return  PerteneceAlfabeto; //el primer apostrofo
        }
        else if (simbolo < c.Ascii && simbolo != c.Apostrofo)
        {   
            return PerteneceAlfabeto;
        }
        else if ((simbolo==c.Apostrofo) && (lexema.length()!=0))
        {
                return PerteneceAlfabeto;}//el apostrofo filnal
        else PerteneceAlfabeto = false; //No pertenece
       return PerteneceAlfabeto;
            
     }
     
     protected Q funTransCadena(Q estado, char simbolo){         
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (simbolo == c.Apostrofo) return Q.q1;                 
             case q1:
                 if (simbolo<c.Ascii && simbolo!=c.Apostrofo && simbolo != c.RetornoCarro) return Q.q1;    
             case q2:
                  if (simbolo==c.Apostrofo)   return Q.q2; 
             case q3:
                  if (simbolo==c.RetornoCarro) return Q.q3;
               }
         return qSalida;
     }
     
     protected TOKEN AFD_Cadena(){   
      Estado=Q.q0;
      lexema="";
      do{
       char Simbolo = this.entrada[this.posicion];        
          
       if (!esAlfabetoCadena(Simbolo)) break;     
          
      
        Estado=funTransCadena(Estado,Simbolo);
        if (Estado.equals(Q.q1) || Estado.equals(Q.q2)){
          lexema=lexema+Simbolo;             
        } 
       this.posicion++;
       
      }while(this.posicion<this.entrada.length && !Estado.equals(Q.q2) && !Estado.equals(Q.q3));
          
      if (Estado.equals(Q.q1)) return TOKEN.ERROR8;
      if (Estado.equals(Q.q2)) return TOKEN.CADENA;
      if (Estado.equals(Q.q3)) return TOKEN.ERROR8;
      return TOKEN.HAS_NEXT;
    }
     
     protected boolean esAlfabetoIDoRES(char simbolo){
       return esLetra(simbolo) || esDigito(simbolo)|| simbolo==c.GuionBajo;
     }
     
     protected Q funTransIDoRES(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (esLetra(simbolo)|| simbolo==c.GuionBajo) return Q.q1;  
             case q1:
               if  (esLetra(simbolo)|| esDigito(simbolo)|| simbolo==c.GuionBajo) return Q.q1;               
         }
       return qSalida; 
     }
     

     protected TOKEN AFD_IDoRES(){
      Estado=Q.q0;
      lexema="";
      do{
        char Simbolo = this.entrada[this.posicion]; 
        
        if (!esAlfabetoIDoRES(Simbolo)) break;
         
        Estado=funTransIDoRES(Estado,Simbolo);
        if (Estado.equals(Q.q1)){
          lexema=lexema+Simbolo;             
        } 
       this.posicion++;
      
      }while(this.posicion<this.entrada.length); 
     if(Estado.equals(Q.q1)) {
      if (isReservada(lexema)) return TOKEN.valueOf(lexema.toUpperCase());//palabra reservada 
      else return TOKEN.ID;  }
     return TOKEN.HAS_NEXT;
     }
     
    protected boolean esAlfabetoDosPuntos(char simbolo){
       return simbolo==c.DosPuntos || simbolo==c.Igual;
     }
     
     protected Q funTransDosPuntos(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (simbolo==c.DosPuntos) return Q.q1;  
             case q1:
               if (simbolo==c.Igual) return Q.q2;
         }
       return qSalida; 
     }
     

     protected TOKEN AFD_DosPuntos(){
      Estado=Q.q0;
      lexema="";
      do{
        char Simbolo = this.entrada[this.posicion]; 
        
        if (!esAlfabetoDosPuntos(Simbolo)) break;
         
        Estado=funTransDosPuntos(Estado,Simbolo);
        if (Estado.equals(Q.q1)){
          lexema=lexema+Simbolo;             
        } 
       this.posicion++;
      
      }while(this.posicion<this.entrada.length); 
     if(Estado.equals(Q.q1)) return TOKEN.DOS_PUNTOS; 
     if(Estado.equals(Q.q2)){ EsSumaoResta=true; return TOKEN.ASIGNACION;}
     return TOKEN.HAS_NEXT;
     }
     
       protected boolean esAlfabetoEnteroReal(char simbolo){
        return (esDigito(simbolo) || simbolo==c.Mas || simbolo==c.Menos || simbolo==c.Exponencial);
     }
     
     protected Q funTransEnteroReal(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (simbolo==c.Mas || simbolo==c.Menos || esDigito(simbolo)) return Q.q1;  
             case q1:
               if (esDigito(simbolo)) return Q.q1;
               else if (simbolo==c.Punto)  return Q.q2;
               else if (simbolo==c.Mas)  return Q.q6;
               else if (simbolo==c.Menos)  return Q.q5;
             case q2: if (esDigito(simbolo)) return Q.q2;
             else if (simbolo==c.Exponencial) return Q.q3;
             case q3:
                 if (simbolo==c.Mas || simbolo==c.Menos) return Q.q4;
             case q4: if(esDigito(simbolo)) return Q.q2;         
         }
       return qSalida; 
     }
     

     protected TOKEN AFD_EnteroReal(){
      Estado=Q.q0;
      lexema="";
     do{
        char Simbolo = this.entrada[this.posicion]; 
        
        if (!esAlfabetoEnteroReal(Simbolo)) break;
         
        Estado=funTransEnteroReal(Estado,Simbolo);
        if ((Estado.equals(Q.q1)||Estado.equals(Q.q2) || Estado.equals(Q.q3) || Estado.equals(Q.q4)) && EsSumaoResta) {
          lexema=lexema+Simbolo;             
        } 
       this.posicion++;
      
      }while(this.posicion<this.entrada.length); 
     if(Estado.equals(Q.q1)) return TOKEN.INTEGER; 
     if(Estado.equals(Q.q2) || Estado.equals(Q.q3) || Estado.equals(Q.q4)) return TOKEN.REAL;
     if(Estado.equals(Q.q6)) {   EsSumaoResta=false; return TOKEN.SUMA;}
     if(Estado.equals(Q.q5)) {  EsSumaoResta=false; return TOKEN.RESTA;}
     return TOKEN.HAS_NEXT;
     }
     
    private boolean esLetra(char car){
        return ((car >= 'a' && car <= 'z') || (car >= 'A' && car <= 'Z'));            
    }
    
    private boolean esDigito(char car){
        return (car >= '0' && car <= '9');
    } 
    
     public boolean isReservada(String res){  
      for(TOKEN tok: TOKEN.values()){     
       // System.out.println(tok.toString());
      if(res.equalsIgnoreCase(tok.toString()))
           return true;
         } 
      return false;
    }
}
