

package Control;

import Modelo.*;
import static Vista.IDE.tblSimbolos;

public class AnalizadorLexico {
   constantes c;
   Q Estado;
   int estado;
   char[] entrada;
   int posicion;
   String lexema = "";
   public int linea;
   char car;
   
    
//CONTRUCTOR
    public AnalizadorLexico(char[] entrada) {   
        this.c =new constantes();
        this.estado = 0;
        this.entrada = entrada;
        this.posicion = 0;
        this.linea=1;
        
    }
      
     public TOKEN automata(){
    TOKEN RToken = TOKEN.NEXT_TOKEN;
      
    while ((this.posicion!=this.entrada.length)){
         car = this.entrada[this.posicion]; 
         //System.out.println(" "+lexema+" >>"+car+"<<");
        if (car==c.SaltoRenglon ) { linea++; this.posicion++;}
        else if(car==c.Tabulador || car==c.Espacio || car==c.RetornoCarro){ this.posicion++;}
        else if(car==c.Apostrofo)
        {  
            return AFD_Cadena();
        }    
        else if (esLetra(car)||car==c.GuionBajo)
        {  
            return AFD_IDoRES();
         
        }else if(car==c.DosPuntos){
            
            return AFD_DosPuntosoAsignacion();
            
        }else if (esDigito(car)){
            
            return AFD_EnteroReal();
            
        }
        else if (car==c.Igual || car==c.MayorQue|| car==c.MenorQue){
            
            return AFD_OpRelacional();
            
        }else if (car==c.Punto){    
           
           return  AFD_PuntoOpuntoPunto();
          
        }else if ("()[]{}".contains(""+car)){    
           TOKEN tipo=TOKEN.CE;
           switch(car){
               case '{': RToken = AFD_ComentL(); tipo=TOKEN.CO; break;
               case '}': RToken = TOKEN.LLAVE_CIERRE; this.posicion++; lexema=""+car;break;
               case '(': RToken = AFD_ComentP(); tipo = (RToken == TOKEN.PARENTESIS_APER) ? TOKEN.CE :TOKEN.CO; break;
               case ')': RToken = TOKEN.PARENTESIS_CIERRE;this.posicion++;lexema=""+car;break;    
               case '[': RToken = TOKEN.CORCHETES_APER;this.posicion++; lexema=""+car;break;
               case ']': RToken = TOKEN.CORCHETES_CIERRE;this.posicion++;lexema=""+car; break;        
           }
          if (RToken!=TOKEN.NEXT_TOKEN) Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,tipo));  
          return RToken; 
        }else if ("$#".contains(""+car)){    
           lexema=""+car;
           this.posicion++;
            switch(car){              
               case '#': RToken =  TOKEN.CAR;break;
               case '$': RToken =  TOKEN.HEX;break;
           }
          Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.CE));  
          return RToken;
        }else if (",;".contains(""+car)){    
           lexema=""+car;
           this.posicion++;
            switch(car){
               case ';': RToken = TOKEN.PUNTOYCOMA; break;
               case ',': RToken =  TOKEN.COMA; break;
            }
          Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.CE));  
          return RToken;
        }else if ("*/+-".contains(""+car)){    
           lexema=""+car;
           this.posicion++;
            switch(car){
               case '*': RToken =  TOKEN.MULTIPLICACION;break;
               case '/': RToken =  TOKEN.DIVISION;break;
               case '+': RToken =  TOKEN.SUMA;break;
               case '-': RToken =  TOKEN.RESTA;break;
           }
          Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.OPA));  
          return RToken;
        }else{          
          this.posicion++;
        }
    
     }
     Vista.IDE.tblSimbolos.add(new Simbolos(TOKEN.EOF,"fin de archivo",linea,TOKEN.EOF));
     return  TOKEN.EOF;    
    }
     
//AFD LEXICIO DE CADENAS
     protected boolean esAlfabetoCadena(char simbolo){
        boolean PerteneceAlfabeto = true; //No pertenece
        if (simbolo==c.Apostrofo ) return PerteneceAlfabeto;
        else if (simbolo!=c.Apostrofo && simbolo!=c.RetornoCarro) return PerteneceAlfabeto;
        else PerteneceAlfabeto = false; //No pertenece
       return PerteneceAlfabeto;
            
     }
   
     protected Q funTransCadena(Q estado, char simbolo){         
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (simbolo == c.Apostrofo) return Q.q1;//apostrofo que abre                 
             case q1:
                 if (simbolo!=c.Apostrofo) return Q.q1; 
                 else return Q.q2;  //apostrofo que cierra cadena
            case q2: 
                if (simbolo == c.Apostrofo) return Q.q1;//apostrofo que abre                 
                else return Q.q3;
         }
         return qSalida;
         
         
     }
     
     protected TOKEN AFD_Cadena(){   
      Estado=Q.q0;
      lexema="";
       TOKEN RToken = TOKEN.NEXT_TOKEN;
      do{
       char Simbolo = this.entrada[this.posicion];        
          
       if (!esAlfabetoCadena(Simbolo)) break; 
           
        Estado=funTransCadena(Estado,Simbolo);
        if (Estado.equals(Q.q1) || Estado.equals(Q.q2)){
          lexema=lexema+Simbolo;             
        } 
       if (Estado.equals(Q.q3) && Simbolo == c.Espacio) Estado=Q.q4;
       this.posicion++;
       
        //System.out.println(" "+lexema+" "+Estado); 
      
      }while(this.posicion<this.entrada.length && !Estado.equals(Q.q3));     
      if (Estado.equals(Q.q3)){this.posicion--; RToken = TOKEN.CADENA;}
      else if (Estado.equals(Q.q1)) RToken = TOKEN.ERROR8;
      else if (Estado.equals(Q.q4)) RToken = TOKEN.ERROR89;
      Vista.IDE.tblSimbolos.add(new Simbolos(RToken ,lexema,linea,TOKEN.CA));
      return RToken ;
    }
     
     
//AFD LEXICIO DE IDENTIFICACDORES O PLABRAS RESERVADAS
     protected boolean esAlfabetoIDoRES(char simbolo){
       return esLetra(simbolo) || esDigito(simbolo)|| simbolo==c.GuionBajo;
     }
     
     protected Q funTransIDoRES(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (esLetra(simbolo)|| simbolo==c.GuionBajo) return Q.q1;  
             case q1:
               if  (esLetra(simbolo)|| esDigito(simbolo)|| simbolo==c.GuionBajo) return Q.q1;               
         }
       return qSalida; 
     }
     
     protected TOKEN AFD_IDoRES(){
      Estado=Q.q0;
      lexema="";
       TOKEN RToken = TOKEN.NEXT_TOKEN;
      do{
        char Simbolo = this.entrada[this.posicion]; 
          
        if (!esAlfabetoIDoRES(Simbolo)) break;
         
        Estado=funTransIDoRES(Estado,Simbolo);
        if (Estado.equals(Q.q1)){
          lexema=lexema+Simbolo;             
        } 
       this.posicion++;
      
      }while(this.posicion<this.entrada.length); 
      if(Estado.equals(Q.q1)) {
        if (isReservada(lexema)){ RToken = TOKEN.valueOf(lexema.toUpperCase());Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.PR)); }//palabra reservada 
        else{ RToken = TOKEN.IDE;Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.ID));}  
       }
     return  RToken;
    }
     
     
//AFD LEXICIO DE : O := 
     protected boolean esAlfabetoDosPuntos(char simbolo){
       return simbolo==c.DosPuntos || simbolo==c.Igual;
     }
  
     protected Q funTransDosPuntos(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (simbolo==c.DosPuntos) return Q.q1;  
             case q1:
               if (simbolo==c.Igual) return Q.q2;
         }
       return qSalida; 
     }
     
     protected TOKEN AFD_DosPuntosoAsignacion(){
      Estado=Q.q0;
      lexema="";
       TOKEN RToken = TOKEN.NEXT_TOKEN;
      do{
        char Simbolo = this.entrada[this.posicion]; 
        
        if (!esAlfabetoDosPuntos(Simbolo)) break;
         
        Estado=funTransDosPuntos(Estado,Simbolo);
        if (Estado.equals(Q.q1)|| Estado.equals(Q.q2)){
          lexema=lexema+Simbolo;             
        } 
       this.posicion++;
      
      }while(this.posicion<this.entrada.length); 
     if (Estado.equals(Q.q1))
     {  RToken = TOKEN.DOS_PUNTOS; 
        Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.CE));      
     }
     else if (Estado.equals(Q.q2))
      {  RToken = TOKEN.ASIGNACION; 
         Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.AS));
      }
     return RToken;
     }

//AFD LEXICIO DE : O := 
     protected boolean esAlfabetoPuntoOpuntoPunto(char simbolo){
       return simbolo==c.Punto;
     }
  
     protected Q funTransesPuntoOpuntoPunto(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (simbolo==c.Punto) return Q.q1;  
             case q1:
               if (simbolo==c.Punto) return Q.q2;
         }
       return qSalida; 
     }
     
     protected TOKEN AFD_PuntoOpuntoPunto(){
      Estado=Q.q0;
      lexema="";
       TOKEN RToken = TOKEN.NEXT_TOKEN;
      do{
        char Simbolo = this.entrada[this.posicion]; 
        
        if (!esAlfabetoPuntoOpuntoPunto(Simbolo)) break;
         
        Estado=funTransesPuntoOpuntoPunto(Estado,Simbolo);
        if (Estado.equals(Q.q1)|| Estado.equals(Q.q2)){
          lexema=lexema+Simbolo;             
        } 
       this.posicion++;
      
      }while(this.posicion<this.entrada.length); 
     if (Estado.equals(Q.q1))
     {  RToken = TOKEN.PUNTO; 
        Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.CE));
       }
     else if (Estado.equals(Q.q2))
      {  RToken = TOKEN.PUNTO_PUNTO; 
         Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.CE));
      }
     return RToken;
     }

//AFD CONSTANTES NUMERICASC  ENETROS O DECIMALES
     protected boolean esAlfabetoEnteroReal(char simbolo){
        return (esDigito(simbolo) || c.Punto==simbolo || Character.toUpperCase(simbolo) ==c.Exponencial || (simbolo==c.Mas || simbolo==c.Menos));
     }
     
     protected Q funTransEnteroReal(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (esDigito(simbolo)) return Q.q1;                   
             case q1:
               if (esDigito(simbolo)) return Q.q1;
               else if (simbolo==c.Punto)  return Q.q2;
               else if (Character.toUpperCase(simbolo)==c.Exponencial) return Q.q3;
               else return Q.q5;      
             case q2: if (esDigito(simbolo)) return Q.q2;
                      else if (Character.toUpperCase(simbolo)==c.Exponencial) return Q.q3;
                      else if (simbolo==c.Mas || simbolo==c.Menos) return Q.q4;
                      else if (simbolo==c.Punto)  return Q.q7;         
                      else return Q.q8;
             case q3:
                 if (simbolo==c.Mas || simbolo==c.Menos) return Q.q4;
             case q4: if(esDigito(simbolo)) return Q.q4;
             else return Q.q6;
         }
       return qSalida; 
     }    

     protected TOKEN AFD_EnteroReal(){
      Estado=Q.q0;
      lexema="";
      TOKEN RToken = TOKEN.NEXT_TOKEN;
     do{
        char Simbolo = this.entrada[this.posicion]; 
        
        if (!esAlfabetoEnteroReal(Simbolo)) break;
         
        Estado=funTransEnteroReal(Estado,Simbolo);
        if ((Estado.equals(Q.q1)||Estado.equals(Q.q2) || Estado.equals(Q.q3)||Estado.equals(Q.q4) || Estado.equals(Q.q7))) {
          lexema=lexema+Simbolo;             
        } 
      
        this.posicion++;
        //System.out.println(" "+lexema+" "+Estado); 
      }while(this.posicion<this.entrada.length && (!Estado.equals(Q.q5)&& !Estado.equals(Q.q6)&& !Estado.equals(Q.q7))); 
     if(Estado.equals(Q.q1)) RToken = TOKEN.NUM; 
     if(Estado.equals(Q.q2)|| Estado.equals(Q.q3) || Estado.equals(Q.q4)) RToken =  TOKEN.DEC;
     if(Estado.equals(Q.q5)) {this.posicion--;RToken = TOKEN.NUM; }
     if(Estado.equals(Q.q6)) {this.posicion--;RToken = TOKEN.DEC; }
     if(Estado.equals(Q.q7)) {this.posicion--;this.posicion=this.posicion-1;lexema=lexema.substring(0,lexema.length()-2);RToken = TOKEN.NUM;}
     if(Estado.equals(Q.q8)) RToken =  TOKEN.ERROR42;
     Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.CN));
     return RToken;
     }
     
//AFD OPERADORES RELACIONALES
    protected boolean esAlfabetoOpRelacional(char simbolo){
       return (simbolo==c.Igual || simbolo==c.MayorQue|| simbolo==c.MenorQue);
     }
     
     protected Q funTransOpRelacional(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
                 if (simbolo==c.MenorQue) return Q.q1;
                 else if (simbolo==c.Igual) return Q.q4;  
                 else if (simbolo==c.MayorQue) return Q.q5;  
             case q1:
               if (simbolo==c.Igual) return Q.q2;
               else if (simbolo==c.MayorQue) return Q.q3;                 
             case q5:
              if (simbolo==c.Igual) return Q.q6;
             case q4: 
              if (simbolo==c.MayorQue||simbolo==c.MenorQue) return Q.q7;
         }
       return qSalida; 
     } 

    protected TOKEN AFD_OpRelacional(){
      Estado=Q.q0;
      lexema="";
      TOKEN RToken = TOKEN.NEXT_TOKEN;
      do{
        char Simbolo = this.entrada[this.posicion]; 
               
        if (!esAlfabetoOpRelacional(Simbolo)) break;

        Estado=funTransOpRelacional(Estado,Simbolo);
        lexema=lexema+Simbolo;             
       
       this.posicion++;
       //System.out.println(" "+lexema+" "+Estado); 
      }while(this.posicion<this.entrada.length );//&& !Estado.equals(Q.q2)&& !Estado.equals(Q.q3)&& !Estado.equals(Q.q4)&& !Estado.equals(Q.q5)&& !Estado.equals(Q.q7)&& !Estado.equals(Q.q8)); 
     if(Estado.equals(Q.q1)) RToken = TOKEN.MENORQUE; 
     else if(Estado.equals(Q.q2)) RToken = TOKEN.MENORIGUALQUE;
     else if(Estado.equals(Q.q3)) RToken = TOKEN.DIFERENTE;
     else if(Estado.equals(Q.q4)) RToken = TOKEN.IGUAL;
     else if(Estado.equals(Q.q5)) RToken = TOKEN.MAYORQUE; 
     else if(Estado.equals(Q.q6)) RToken = TOKEN.MAYORIGUALQUE;
     else if(Estado.equals(Q.q7)) RToken = TOKEN.ERROR42; 
     Vista.IDE.tblSimbolos.add(new Simbolos(RToken,lexema,linea,TOKEN.OPR));
     return RToken;
     }  
     

     
     protected Q funTransComentP(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
               if (simbolo=='(') return Q.q1;                 
             case q1:
               if (simbolo=='*') return Q.q2;
               return Q.q5;//Parentesis que abre
              case q2:  
                if (simbolo=='*') return Q.q3;//buscando Fin comentario
                else return Q.q2;//sigue buscando Fin comentario       
              case q3:                   
                if (simbolo==')') return Q.q4;//Fin comentario        
                else return Q.q2;//sigue buscando Fin comentario     
                }    
       return qSalida; 
     } 

     protected TOKEN AFD_ComentP(){
      Estado=Q.q0;
      lexema="";
  
      TOKEN RToken = TOKEN.NEXT_TOKEN;
      do{
        char Simbolo = this.entrada[this.posicion]; 
                  
        Estado=funTransComentP(Estado,Simbolo);
        if (Estado.equals(Q.q1)){
          lexema=lexema+Simbolo;             
        } 
        if (Estado.equals(Q.q2)){ 
          if (Simbolo==c.SaltoRenglon) linea++;  
        }
       this.posicion++;
       //System.out.println(" "+Simbolo+" "+Estado); 
      }while(this.posicion<this.entrada.length && !Estado.equals(Q.q5)&& !Estado.equals(Q.q4)); 
     if(Estado.equals(Q.q5)) {RToken = TOKEN.PARENTESIS_APER; this.posicion--;}
      if(Estado.equals(Q.q4)) {RToken = TOKEN.COMENTARIO;lexema="(*C*)";}
      if(Estado.equals(Q.q2)) RToken = TOKEN.ERROR10;
      return RToken;
     }  
     
     
   protected Q funTransComentL(Q estado, char simbolo){
         Q qSalida=estado;
         switch (estado){
             case q0:
               if (simbolo=='{') return Q.q1;                 
             case q1:
                if (simbolo!='}' && simbolo!='{') return Q.q1; //sige buscando fin de comentario
                else  if (simbolo=='{') return Q.q4; // comentario anidadado del mismo tipo no permitido
                else return Q.q2;
              case q2:  
                if (simbolo=='}') return Q.q3;//Fin comentario        
                }    
       return qSalida; 
     } 

     protected TOKEN AFD_ComentL(){
      Estado=Q.q0;
      lexema="";
      TOKEN RToken = TOKEN.NEXT_TOKEN;
      do{
        char Simbolo = this.entrada[this.posicion]; 
              
        Estado=funTransComentL(Estado,Simbolo);
        if (Estado.equals(Q.q1)){ 
          if (Simbolo==c.SaltoRenglon) linea++;  
        }
       lexema=""+Simbolo; 
       if (!Estado.equals(Q.q2)) this.posicion++;
       //System.out.println(" "+lexema+" "+Estado); 
      }while(this.posicion<this.entrada.length && !Estado.equals(Q.q3) && !Estado.equals(Q.q4)); 
      if(Estado.equals(Q.q3)) { RToken = TOKEN.COMENTARIO;lexema="{C}";}
      else if(Estado.equals(Q.q4)) {RToken = TOKEN.ERROR216;}
      return RToken;
     }    
//METODOS VARIOS
    private boolean esLetra(char car){
        return ((car >= 'a' && car <= 'z') || (car >= 'A' && car <= 'Z'));            
    }
    
    private boolean esDigito(char car){
        return (car >= '0' && car <= '9');
    } 
    
    public boolean isReservada(String res){  
      for(TOKEN tok: TOKEN.values()){     
       // System.out.println(tok.toString());
      if(res.equalsIgnoreCase(tok.toString()))
           return true;
         } 
      return false;
    }
}
