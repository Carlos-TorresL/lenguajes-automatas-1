/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modelo;

/**
 *
 * @author w
 */
public class constantes{
    
    public final String Letras="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    public final String Digitos="0123456789";
    public final String Delimitadores=";, ";
    ///Disparadores
    public final String esSimboloDescartables="\r\n\t ";
    public final String esSaltoDeLinea="\n";
    public final String esOperadoresAritmeticos="*/+-";
    public final String esOperadoresRelacionales="<>=";
    public final String esSimboloAgrupacion="(){}[]";
    public final String esIdeOReservada=Letras+'_';  
    public final String esNumero="+-"+Digitos;  
    public final String esCadena="\'";
    public final String esAsignacionODosPuntos=":";
    
    //Alfabetos
    public final String AlfabetoNumeros=Digitos+"+-.E"+Digitos;
    public final String AlfabetoIdeoReservada=Letras+Digitos+'_';      
    public final String AlfabetoAsignacion=":=";
    
    public final char Apostrofo= '\'';
    public final char SaltoRenglon = '\n';
    public final char RetornoCarro = '\r';
    public final char Tabulador = '\t';
    public final char Espacio = ' ';
    public final char Ascii = '�';
    public final char DosPuntos = ':';
    public final char Igual = '=';
    public final char Mas = '+';
    public final char Menos = '-';
    public final char Exponencial = 'E';
    public final char Punto = '.';
    public final char GuionBajo='_';
   


}