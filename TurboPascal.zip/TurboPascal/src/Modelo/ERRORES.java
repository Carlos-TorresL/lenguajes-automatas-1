/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modelo;

/**
 *
 * @author w
 */
public enum ERRORES{
        ERROR2,ERROR5,ERROR8,ERROR10,ERROR17, ERROR20, ERROR21,ERROR36, ERROR42,ERROR64,ERROR85,ERROR86,ERROR87,
        ERROR88, ERROR89,ERROR94,ERROR97,ERROR113,ERROR216, SIN_ERROR, EOF;
        @Override
        public String toString(){
            switch (this) {
                case ERROR2:
                    return "Error 2: se esperaba un identificador"; 
                case ERROR5:
                    return "Error 5: error de sintaxis";     
                case ERROR8:
                    return "Error  8: constante de cadena excede la linea"; 
                case ERROR10:
                    return "Error 10: no se esperaba fin de archivo";     
                case ERROR17:
                    return "Error 17: Directiva del compilador no valida";
                case ERROR20:
                    return "Error 20: se esperaba identificador de variable";   
                case ERROR21:
                    return "Error 21: error de tipo";
                case ERROR36:
                    return "Error 36: se esperaba BEGIN";             
                case ERROR42:
                    return "Error 42: error en la expresión";
                case ERROR64:
                    return "Error 64: no se puede leer o escribir variables de ese tipo";     
                case ERROR85:
                    return "Error 85: se esperaba \";\" ";       
                case ERROR86:
                    return "Error 86: se esperaba \":\" ";
                case ERROR87:
                    return "Error 87: se esperaba \",\" ";    
                case ERROR88:
                    return "Error 88: se esperaba \"(\" ";                          
                case ERROR89:
                    return "Error 89: se esperaba \")\" "; 
                case ERROR94:
                    return "Error 94: se esperaba \".\" "; 
                case ERROR97:
                    return "Error 94: se esperaba \"=\" ";     
                case ERROR113:
                    return "Error 113: error en sentencia. ";       
                case ERROR216:
                    return "Error 216: comentarios anidados no permitidos";             
                case SIN_ERROR:    
                    return "Compilacion exitosa";
            default:
                return "";
            }
        }
    }