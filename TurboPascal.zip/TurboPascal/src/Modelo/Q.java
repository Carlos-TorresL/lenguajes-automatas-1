/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modelo;

/**
 *
 * @author w
 */
public enum Q{
     /*   q0("q0",0), q1("q1",1), q2("q2",2), q3("q3",3), q4("q4",4),
        q5("q5",5), q6("q6",6), q7("q7",7);*/
        q0,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11
       /* private final String qN;
	private final int qV;
       
        Q(String Name,int Valor){
            this.qN=Name;
            this.qV=Valor;     
        } 
        */
       
        
      }