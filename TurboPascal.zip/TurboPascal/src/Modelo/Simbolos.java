/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package Modelo;


/**
 *
 * @author w
 */
public class Simbolos {
    private TOKEN token;
    private String lexema;
    private int linea;
    private TOKEN tipo;
    
    public Simbolos() {
    }

    public Simbolos(TOKEN NToken, String lexema,int fila, TOKEN tipo) {
        this.token=NToken;
        this.lexema = lexema;
        this.linea = fila;
        this.tipo = tipo;
    }

    
public TOKEN getToken() {
        return token;
    }

    public void sToken(TOKEN token) {
        this.token = token;
    }
    
    public String getLexema() {
        return lexema;
    }

    public void setLexema(String lexema) {
        this.lexema = lexema;
    }
 

    public int getLinea() {
        return linea;
    }

    public void setFila(int fila) {
        this.linea = fila;
    }

  
    public TOKEN getTipo() {
        return tipo;
    }

    public void setTipo(TOKEN tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "   linea " + linea +" lexema  " + lexema + "  tipo " + tipo + " ";
    }
    
    
    
}
