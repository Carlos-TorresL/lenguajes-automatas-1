/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Control.AnalizadorLexico;
import Modelo.TOKEN;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.text.*;

/**
 *
 * @author w
 */
public class IDE extends javax.swing.JFrame {
/*    public static ArrayList<Reservadas> lista_Reservadas;
    public static ArrayList<Identificadores> lista_Identificadores;
    public static ArrayList<Token> lista_Token ;*/
    NumeroLinea numerolinea;
    Directorio dir;

    /**
     * Creates new form IDE
     */
    public IDE() {
        initComponents();
        inicializar();
    }
    
    @SuppressWarnings("static-access")
  private void inicializar() {
        setTitle("#noname");
        @SuppressWarnings("MismatchedReadAndWriteOfArray")
        String[] options = new String[]{"Guardar y continuar", "Abrir"};
        /*this.lista_Reservadas = new ArrayList();
        this.lista_Identificadores = new ArrayList();
        this.lista_Token= new ArrayList();*/
        dir = new Directorio();
        numerolinea = new NumeroLinea(jtpCode);//  se hace la numeracion
        jScrollPane1.setRowHeaderView(numerolinea);
        colors();
    }
  
    private int findLastNonWordChar(String text, int index) {
        while (--index >= 0) {
            // \\W = [A-Za-Z0-9]
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
        }
        return index;
    }

    private int findFirstNonWordChar(String text, int index) {
        while (index < text.length()) {
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
            index++;
        }
        return index;
    }

    private void colors() {

        final StyleContext cont = StyleContext.getDefaultStyleContext();

        //Colores
        final AttributeSet attRed   = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(192, 57, 43));
        final AttributeSet attGreen = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(35, 155, 86));
        final AttributeSet attBlue  = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(144, 56, 249));
        final AttributeSet attBlack = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(0, 0, 0));
        final AttributeSet attBrown = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(144, 56, 10));
        final AttributeSet attm     = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, new Color(144, 0, 144));

        //Estilo
        DefaultStyledDocument doc = new DefaultStyledDocument() {
            @Override
            public void insertString(int offset, String str, AttributeSet a) throws BadLocationException {
                super.insertString(offset, str, a);

                String text = getText(0, getLength());
                int before = findLastNonWordChar(text,offset);
                if (before < 0) {
                    before = 0;
                }
                int after = findFirstNonWordChar(text,offset + str.length());
                int wordL = before;
                int wordR = before;

                while (wordR <= after) {
                    if (wordR == after || String.valueOf(text.charAt(wordR)).matches("\\W")) {
                        if (text.substring(wordL, wordR).toUpperCase().matches("(\\W)*(AND|ASM|ARRAY|BEGIN|CASE|CONST|"
                                + "CONSTRUCTOR|DESTRUCTOR|DIV|DO|DOWNTO|ESLES|END|EXPORTS|FILE|FOR|FUCTION|"
                                + "GOTO|IF|IMPLEMENTATION|IN|INHERITRD|INLINE|INTERFACE|ID|LABEL|LIBRARY|MOD|"
                                + "NIL|NOT|OBJECT|OF|OR|PACKED|PROCEDURE|PROGRAM|RECORD|REPEAT|SET|SHL|SHR|STRING|"
                                + "THEN|TO|TYPE|UNIT|UNTIL|USES|VAR|WHILE|WITH|XOR|"
                                + "PARENTESIS_APER|PARENTESIS_CIERRE|ERROR|HAS_NEXT|EOF)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attBlue, false);
                        } else if (text.substring(wordL, wordR).toUpperCase().matches("(\\W)*(INTEGER|REAL|BOOLEAN|CHAR)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attGreen, false);
                        } else if (text.substring(wordL, wordR).toUpperCase().matches("(\\W)*(WRITE|WRITELN|READ|READLN)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attRed, false);
                        } else if (text.substring(wordL, wordR).matches("([;|:|=])")) {
                            setCharacterAttributes(wordL, wordR - wordL, attBrown, false);
                        }else {
                            setCharacterAttributes(wordL, wordR - wordL, attBlack, false);
                        }
                        wordL = wordR;
                    }
                    wordR++;
                }
            }

            public void romeve(int offs, int len) throws BadLocationException {
                super.remove(offs, len);

                String text = getText(0, getLength());
                int before = findLastNonWordChar(text, offs);
                if (before < 0) {
                    before = 0;
                }
            }
        };
        JTextPane txt = new JTextPane(doc);
        String temp = jtpCode.getText();
        jtpCode.setStyledDocument(txt.getStyledDocument());
        jtpCode.setText(temp);
    }

    public void clearAllComp() {
        jtaCompile.setText("");
    }

  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jtpCode = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtaCompile = new javax.swing.JTextArea();
        btnGuardar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        btnAbrir = new javax.swing.JButton();
        btnReservadas = new javax.swing.JButton();
        btnIdentificadores = new javax.swing.JButton();
        btnTokens = new javax.swing.JButton();
        btnLexico = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnSintactico = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jtaList = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtpCode.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jtpCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtpCodeKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jtpCode);

        jtaCompile.setColumns(20);
        jtaCompile.setRows(5);
        jScrollPane2.setViewportView(jtaCompile);

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Guardar.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Guardar.png"))); // NOI18N
        btnGuardar.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Guardar.png"))); // NOI18N
        btnGuardar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Guardar.png"))); // NOI18N
        btnGuardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Nuevo.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnNuevo.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Nuevo.png"))); // NOI18N
        btnNuevo.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Nuevo.png"))); // NOI18N
        btnNuevo.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Nuevo.png"))); // NOI18N
        btnNuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Abrir.png"))); // NOI18N
        btnAbrir.setText("Abrir");
        btnAbrir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAbrir.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Abrir.png"))); // NOI18N
        btnAbrir.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Abrir.png"))); // NOI18N
        btnAbrir.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Abrir.png"))); // NOI18N
        btnAbrir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });

        btnReservadas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Reservadas.png"))); // NOI18N
        btnReservadas.setText("Reservadas");
        btnReservadas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnReservadas.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Reservadas.png"))); // NOI18N
        btnReservadas.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Reservadas.png"))); // NOI18N
        btnReservadas.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Reseravadas.png"))); // NOI18N
        btnReservadas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnReservadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservadasActionPerformed(evt);
            }
        });

        btnIdentificadores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Identificadores.png"))); // NOI18N
        btnIdentificadores.setText("Identificadores");
        btnIdentificadores.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIdentificadores.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Identificadores.png"))); // NOI18N
        btnIdentificadores.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Identificadores.png"))); // NOI18N
        btnIdentificadores.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Identificadores.png"))); // NOI18N
        btnIdentificadores.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Identificadores.png"))); // NOI18N
        btnIdentificadores.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnIdentificadores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIdentificadoresActionPerformed(evt);
            }
        });

        btnTokens.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Tokens.png"))); // NOI18N
        btnTokens.setText("Tokens");
        btnTokens.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTokens.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Tokens.png"))); // NOI18N
        btnTokens.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Tokens.png"))); // NOI18N
        btnTokens.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Tokens.png"))); // NOI18N
        btnTokens.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Tokens.png"))); // NOI18N
        btnTokens.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTokens.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTokensActionPerformed(evt);
            }
        });

        btnLexico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Lexico.png"))); // NOI18N
        btnLexico.setText("Lexico");
        btnLexico.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnLexico.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Lexico.png"))); // NOI18N
        btnLexico.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Lexico.png"))); // NOI18N
        btnLexico.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Lexico.png"))); // NOI18N
        btnLexico.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Lexico.png"))); // NOI18N
        btnLexico.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnLexico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLexicoActionPerformed(evt);
            }
        });

        jLabel1.setText("jLabel1");

        btnSintactico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Iconos/Sintactico.png"))); // NOI18N
        btnSintactico.setText("Sintactico");
        btnSintactico.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnSintactico.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Sintactico.png"))); // NOI18N
        btnSintactico.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Encima/Sintactico.png"))); // NOI18N
        btnSintactico.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Sintactico.png"))); // NOI18N
        btnSintactico.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/Iconos/Presionados/Sintactico.png"))); // NOI18N
        btnSintactico.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnSintactico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSintacticoActionPerformed(evt);
            }
        });

        jtaList.setColumns(20);
        jtaList.setRows(5);
        jScrollPane3.setViewportView(jtaList);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jLabel1))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(9, 9, 9)
                                    .addComponent(btnNuevo)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnGuardar)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnAbrir)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnReservadas)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnIdentificadores)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnTokens)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnLexico)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnSintactico))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 321, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGuardar)
                    .addComponent(btnNuevo)
                    .addComponent(btnAbrir)
                    .addComponent(btnReservadas)
                    .addComponent(btnIdentificadores)
                    .addComponent(btnTokens)
                    .addComponent(btnSintactico)
                    .addComponent(btnLexico))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 476, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        jtaCompile.setText("");
        dir.Nuevo(this);
        clearAllComp();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        dir.Guardar(this);
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        dir.Abrir(this);
        clearAllComp();
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnReservadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservadasActionPerformed
      /*  jtaList.setText("");
        for(int i = 0; i < lista_Reservadas.size(); i++){
            jtaList.setText(jtaList.getText() + "\n" + lista_Reservadas.get(i).toString());
        }*/
    }//GEN-LAST:event_btnReservadasActionPerformed

    private void jtpCodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtpCodeKeyReleased
        //no permitir caracteres especiales en los nombres de archivos 
        int keyCode = evt.getKeyCode();
        //65:A-90:Z 48:0-57:1 97:a-122:z 40:0-16:1 
        if ((keyCode >= 65) && (keyCode <= 90) || (keyCode >= 48) && (keyCode <= 57)
                || (keyCode >= 97) && (keyCode <= 122) || (keyCode != 27) && !(keyCode >= 37
                && keyCode <= 40) && !(keyCode >= 16
                && keyCode <= 18) && !(keyCode != 254
                && keyCode != 20)) {
            if (!getTitle().contains("*")) {
                setTitle(getTitle() + "*");
            }

        }


    }//GEN-LAST:event_jtpCodeKeyReleased

    private void btnIdentificadoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIdentificadoresActionPerformed
       /* jtaList.setText("");
        for(int i = 0; i < lista_Identificadores.size(); i++){
            jtaList.setText(jtaList.getText() + "\n" + lista_Identificadores.get(i).toString());
        }*/
    }//GEN-LAST:event_btnIdentificadoresActionPerformed

    private void btnTokensActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTokensActionPerformed
       /* jtaList.setText("");
        for(int i = 0; i < lista_Token.size(); i++){
            jtaList.setText(jtaList.getText() + "\n" + lista_Token.get(i).toString());
        }*/
    }//GEN-LAST:event_btnTokensActionPerformed

    private void btnLexicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLexicoActionPerformed
        clearAllComp();
        //lista_Reservadas.clear();lista_Identificadores.clear();lista_Token.clear();
        StringBuilder buffer = new StringBuilder();     
        TOKEN token;
        AnalizadorLexico a = new AnalizadorLexico(jtpCode.getText().toCharArray(),true);
        do{
            token = a.automata();
            if (token != TOKEN.HAS_NEXT)
                    buffer.append(token.toString()+"\n");
        }while (token != TOKEN.EOF);
        
        jtaCompile.setText(buffer.toString());
        
    }//GEN-LAST:event_btnLexicoActionPerformed

    private void btnSintacticoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSintacticoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSintacticoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new IDE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnIdentificadores;
    private javax.swing.JButton btnLexico;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnReservadas;
    private javax.swing.JButton btnSintactico;
    private javax.swing.JButton btnTokens;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jtaCompile;
    private javax.swing.JTextArea jtaList;
    public javax.swing.JTextPane jtpCode;
    // End of variables declaration//GEN-END:variables
}
